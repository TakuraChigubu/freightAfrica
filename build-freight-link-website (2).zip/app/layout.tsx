import type { Metadata, Viewport } from 'next'
import { Inter, Poppins } from 'next/font/google'
import { Toaster } from '@/components/ui/sonner'
import './globals.css'

const inter = Inter({ variable: '--font-inter', subsets: ['latin'] })
const poppins = Poppins({
  variable: '--font-poppins',
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
})

export const metadata: Metadata = {
  title: {
    default: 'FreightLink Africa — AI-Powered Freight Load Board',
    template: '%s | FreightLink Africa',
  },
  description:
    'Post loads, find return trips, and connect shippers with drivers across the African trucking corridor. AI-powered matching starting Zimbabwe ↔ South Africa.',
  keywords: ['freight', 'logistics', 'Africa', 'load board', 'trucking', 'Zimbabwe', 'South Africa'],
  openGraph: {
    title: 'FreightLink Africa — AI-Powered Freight Load Board',
    description:
      'Post loads, find return trips, and connect shippers with drivers across the African trucking corridor.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#1e2d5a',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${poppins.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  )
}
