import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { getSessionUserId } from '@/lib/admin-auth'
import { AdminLoginForm } from '@/components/admin/admin-login-form'
import Image from 'next/image'

export const metadata: Metadata = { title: 'Admin Login' }

export default async function AdminLoginPage() {
  // Already authenticated — go straight to dashboard
  const userId = await getSessionUserId()
  if (userId) redirect('/admin')

  return (
    <main className="flex min-h-screen items-center justify-center bg-sidebar p-4">
      <div className="w-full max-w-sm space-y-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-lg">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%20Jun%2028%2C%202026%2C%2009_11_04%20PM-1wLIdcjf7uQBOAfry1fnBxuBHMKt8h.png"
              alt="FreightLink Africa"
              width={56}
              height={56}
              className="object-contain"
            />
          </div>
          <div>
            <h1 className="font-heading text-xl font-bold text-sidebar-foreground">
              FreightLink Africa
            </h1>
            <p className="text-sm text-sidebar-foreground/60">Admin Panel</p>
          </div>
        </div>

        {/* Login card */}
        <div className="rounded-xl border border-sidebar-border bg-sidebar-accent p-6 shadow-lg">
          <h2 className="mb-5 font-heading text-base font-semibold text-sidebar-foreground">
            Sign in to continue
          </h2>
          <AdminLoginForm />
        </div>

        <p className="text-center text-xs text-sidebar-foreground/40">
          FreightLink Africa &copy; {new Date().getFullYear()}
        </p>
      </div>
    </main>
  )
}
