import type { Metadata } from 'next'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { MessageCircle, Send, Zap, Globe, CreditCard, Users } from 'lucide-react'
import { siteConfig } from '@/lib/site'
import { PaynowConfigForm } from '@/components/admin/paynow-config-form'
import { AdminManagementPanel } from '@/components/admin/admin-management-panel'

export const metadata: Metadata = { title: 'Settings' }

export default function AdminSettingsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Platform configuration, integrations and contact channels.
        </p>
      </div>

      {/* Site info */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Globe className="h-4 w-4 text-accent" />
            Site information
          </CardTitle>
          <CardDescription>Basic platform identity and branding.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Platform name</Label>
              <Input defaultValue={siteConfig.name} readOnly className="bg-muted/50" />
            </div>
            <div className="space-y-2">
              <Label>Site URL</Label>
              <Input defaultValue={siteConfig.url} readOnly className="bg-muted/50" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Tagline</Label>
            <Input defaultValue={siteConfig.tagline} readOnly className="bg-muted/50" />
          </div>
          <p className="text-xs text-muted-foreground">
            Update these values in <code className="rounded bg-muted px-1 py-0.5 text-xs">lib/site.ts</code> and redeploy.
          </p>
        </CardContent>
      </Card>

      {/* Contact channels */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <MessageCircle className="h-4 w-4 text-[#25D366]" />
            Contact channels
          </CardTitle>
          <CardDescription>WhatsApp, Telegram and email endpoints shown to users.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <MessageCircle className="h-3.5 w-3.5 text-[#25D366]" /> WhatsApp URL
              </Label>
              <Input defaultValue={siteConfig.contact.whatsapp} readOnly className="bg-muted/50 font-mono text-xs" />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Send className="h-3.5 w-3.5 text-[#229ED9]" /> Telegram URL
              </Label>
              <Input defaultValue={siteConfig.contact.telegram} readOnly className="bg-muted/50 font-mono text-xs" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input defaultValue={siteConfig.contact.email} readOnly className="bg-muted/50" />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input defaultValue={siteConfig.contact.phone} readOnly className="bg-muted/50" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Replace placeholder values in <code className="rounded bg-muted px-1 py-0.5 text-xs">lib/site.ts</code> with your real phone numbers.
          </p>
        </CardContent>
      </Card>

      {/* Paynow payment gateway */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <CreditCard className="h-4 w-4 text-accent" />
            Paynow payment gateway
          </CardTitle>
          <CardDescription>
            Enter your Paynow Integration ID and Key to activate the $1 unlock
            and subscription checkout flows across the platform.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <PaynowConfigForm />
        </CardContent>
      </Card>

      {/* Admin accounts */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Users className="h-4 w-4 text-accent" />
            Admin accounts
          </CardTitle>
          <CardDescription>
            Change your password or manage admin users. Only superadmins can add
            or remove accounts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AdminManagementPanel />
        </CardContent>
      </Card>

      {/* AI integration */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base flex items-center gap-2">
            <Zap className="h-4 w-4 text-accent" />
            AI assistant
          </CardTitle>
          <CardDescription>Powered by Vercel AI Gateway — no extra API key required.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="text-sm font-medium">AI Gateway</p>
              <p className="text-xs text-muted-foreground">Model: openai/gpt-4o-mini · Max tokens: 512</p>
            </div>
            <Badge className="bg-accent/15 text-accent-foreground border-accent/20">Connected</Badge>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div>
              <p className="text-sm font-medium">Chat endpoint</p>
              <p className="text-xs font-mono text-muted-foreground">POST /api/chat</p>
            </div>
            <Badge variant="outline">Active</Badge>
          </div>
          <p className="text-xs text-muted-foreground">
            Edit the system prompt in <code className="rounded bg-muted px-1 py-0.5 text-xs">app/api/chat/route.ts</code> to customise the assistant&apos;s knowledge and tone.
          </p>
        </CardContent>
      </Card>


    </div>
  )
}
