import type { Metadata } from 'next'
import { AdminUsersTable } from '@/components/admin/admin-users-table'

export const metadata: Metadata = { title: 'Users' }

export default function AdminUsersPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold text-foreground">Users</h1>
        <p className="text-sm text-muted-foreground">
          Manage registered shippers, drivers and brokers on the platform.
        </p>
      </div>
      <AdminUsersTable />
    </div>
  )
}
