import { AdminLoadsTable } from "@/components/admin/admin-loads-table"

export default function AdminLoadsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold text-foreground">Loads</h1>
        <p className="text-sm text-muted-foreground">Review, search and moderate every load on the platform.</p>
      </div>
      <AdminLoadsTable />
    </div>
  )
}
