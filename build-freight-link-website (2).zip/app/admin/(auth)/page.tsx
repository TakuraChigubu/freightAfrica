import type { Metadata } from 'next'
import { Package, Users, Receipt, Globe, TrendingUp, CheckCircle2 } from 'lucide-react'
import { StatCard } from '@/components/admin/stat-card'
import { ActivityChart } from '@/components/admin/activity-chart'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { mockLoads, mockTransactions, platformStats, formatPrice, timeAgo, countries } from '@/lib/data'

export const metadata: Metadata = { title: 'Dashboard' }

export default function AdminDashboardPage() {
  const recentLoads = mockLoads.slice(0, 5)
  const recentTx = mockTransactions.slice(0, 5)

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Overview of FreightLink Africa platform activity.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        <StatCard label="Active loads" value={platformStats.activeLoads} icon={Package} />
        <StatCard label="Registered users" value={platformStats.totalUsers} icon={Users} />
        <StatCard label="Loads this week" value={platformStats.loadsThisWeek} icon={TrendingUp} />
        <StatCard label="Matched this week" value={platformStats.matchedThisWeek} icon={CheckCircle2} />
        <StatCard label="Countries covered" value={platformStats.countriesCovered} icon={Globe} />
        <StatCard label="Revenue (demo)" value="$2,420" icon={Receipt} hint="Last 30 days" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ActivityChart />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="font-heading text-base">Recent transactions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {recentTx.map((tx) => (
              <div key={tx.id} className="flex items-center justify-between gap-2 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-medium text-foreground">{tx.userName}</p>
                  <p className="text-xs text-muted-foreground">{tx.type.replace(/_/g, ' ')}</p>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-semibold">{formatPrice(tx.amount, tx.currency)}</span>
                  <Badge
                    variant={tx.status === 'completed' ? 'default' : tx.status === 'pending' ? 'secondary' : 'destructive'}
                    className="text-[10px]"
                  >
                    {tx.status}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-base">Latest loads posted</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          {recentLoads.map((load) => (
            <div
              key={load.id}
              className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 pb-3 text-sm last:border-0 last:pb-0"
            >
              <div className="min-w-0">
                <p className="font-medium text-foreground">
                  {load.originCity} {countries[load.originCountry].flag} → {load.destCity}{' '}
                  {countries[load.destCountry].flag}
                </p>
                <p className="text-xs text-muted-foreground">
                  {load.cargoType} · {load.weightTonnes}t · {timeAgo(load.postedAt)}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="capitalize">{load.source}</Badge>
                <span className="font-semibold">{formatPrice(load.price, load.currency)}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
