import type { Metadata } from 'next'
import { AdminTransactionsTable } from '@/components/admin/admin-transactions-table'

export const metadata: Metadata = { title: 'Transactions' }

export default function AdminTransactionsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-bold text-foreground">Transactions</h1>
        <p className="text-sm text-muted-foreground">
          All payment events — unlocks, subscriptions and refunds.
        </p>
      </div>
      <AdminTransactionsTable />
    </div>
  )
}
