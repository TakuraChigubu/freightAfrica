/**
 * GET /api/loads
 * Public loads feed. Returns active loads with optional filters.
 * Falls back to mock data if Supabase env vars are not configured.
 */
import { NextRequest, NextResponse } from 'next/server'
import { mockLoads, type Load } from '@/lib/data'
import type { DbLoad } from '@/lib/supabase/queries'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

/** Convert camelCase mock Load into the snake_case DbLoad shape so the browser gets a consistent contract. */
function mockToDb(l: Load): DbLoad {
  return {
    id: l.id,
    reference: l.id,
    origin_city: l.originCity,
    origin_country: l.originCountry,
    dest_city: l.destCity,
    dest_country: l.destCountry,
    cargo_type: l.cargoType,
    cargo_category: l.cargoCategory,
    weight_tonnes: l.weightTonnes,
    truck_type: l.truckType,
    ready_date: null,
    price_amount: l.price,
    price_currency: l.currency,
    negotiable: true,
    status: l.isActive ? 'active' : 'taken',
    confidence: null,
    source: l.source,
    wa_message_id: null,
    posted_at: l.postedAt,
    updated_at: l.postedAt,
    boosted_until: null,
    verification_badge: false,
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const origin = searchParams.get('origin') ?? ''
  const dest = searchParams.get('dest') ?? ''
  const truck = searchParams.get('truck') ?? ''
  const category = searchParams.get('category') ?? ''
  const query = searchParams.get('q') ?? ''
  const sort = (searchParams.get('sort') ?? 'newest') as 'newest' | 'price-high' | 'price-low'

  if (!SUPABASE_CONFIGURED) {
    let loads = [...mockLoads]
    if (origin) loads = loads.filter((l) => l.originCountry === origin)
    if (dest) loads = loads.filter((l) => l.destCountry === dest)
    if (truck) loads = loads.filter((l) => l.truckType === truck)
    if (category) loads = loads.filter((l) => l.cargoCategory === category)
    if (query) {
      const q = query.toLowerCase()
      loads = loads.filter((l) =>
        [l.originCity, l.destCity, l.cargoType, l.cargoCategory]
          .join(' ')
          .toLowerCase()
          .includes(q),
      )
    }
    if (sort === 'price-high') loads.sort((a, b) => b.price - a.price)
    else if (sort === 'price-low') loads.sort((a, b) => a.price - b.price)
    else loads.sort((a, b) => new Date(b.postedAt).getTime() - new Date(a.postedAt).getTime())

    return NextResponse.json({ loads: loads.map(mockToDb), source: 'mock' })
  }

  try {
    const { getLoads } = await import('@/lib/supabase/queries')
    const loads = await getLoads({
      origin_country: origin || undefined,
      dest_country: dest || undefined,
      truck_type: truck || undefined,
      cargo_category: category || undefined,
      query: query || undefined,
      sort,
    })
    return NextResponse.json({ loads, source: 'supabase' })
  } catch (err) {
    console.error('[loads API] Supabase error, falling back to mock:', err)
    return NextResponse.json({ loads: mockLoads, source: 'mock-fallback' })
  }
}
