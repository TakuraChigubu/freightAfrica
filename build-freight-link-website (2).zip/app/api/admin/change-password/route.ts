import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { getCurrentAdmin, readAdmins, writeAdmins } from '@/lib/admin-auth'

export async function POST(req: NextRequest) {
  try {
    const currentAdmin = await getCurrentAdmin()
    if (!currentAdmin) {
      return NextResponse.json({ success: false, error: 'Not authenticated.' }, { status: 401 })
    }

    const { currentPassword, newPassword, targetUserId } = await req.json()

    // Allow superadmin to reset any user's password without providing current password
    const isSuperadmin = currentAdmin.role === 'superadmin'
    const changingOwnPassword = !targetUserId || targetUserId === currentAdmin.id

    const admins = readAdmins()

    if (changingOwnPassword) {
      // Must verify current password
      const match = await bcrypt.compare(currentPassword, currentAdmin.passwordHash)
      if (!match) {
        return NextResponse.json({ success: false, error: 'Current password is incorrect.' }, { status: 400 })
      }
      if (!newPassword || newPassword.length < 8) {
        return NextResponse.json({ success: false, error: 'New password must be at least 8 characters.' }, { status: 400 })
      }
      const updated = admins.map((a) =>
        a.id === currentAdmin.id
          ? { ...a, passwordHash: bcrypt.hashSync(newPassword, 12) }
          : a,
      )
      writeAdmins(updated)
      return NextResponse.json({ success: true })
    }

    // Superadmin resetting another admin's password
    if (!isSuperadmin) {
      return NextResponse.json({ success: false, error: 'Only superadmins can reset other users\' passwords.' }, { status: 403 })
    }
    if (!newPassword || newPassword.length < 8) {
      return NextResponse.json({ success: false, error: 'New password must be at least 8 characters.' }, { status: 400 })
    }

    const targetExists = admins.some((a) => a.id === targetUserId)
    if (!targetExists) {
      return NextResponse.json({ success: false, error: 'Admin not found.' }, { status: 404 })
    }

    const updated = admins.map((a) =>
      a.id === targetUserId
        ? { ...a, passwordHash: bcrypt.hashSync(newPassword, 12) }
        : a,
    )
    writeAdmins(updated)
    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('[Change password] error:', err)
    return NextResponse.json({ success: false, error: 'Internal server error.' }, { status: 500 })
  }
}
