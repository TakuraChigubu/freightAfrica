/**
 * Admin loads API — requires a valid admin session cookie.
 *
 * GET  /api/admin/loads          → list all loads
 * PATCH /api/admin/loads         → update status { id, status }
 * DELETE /api/admin/loads?id=xxx → delete a load
 */
import { NextRequest, NextResponse } from 'next/server'
import { getCurrentAdmin } from '@/lib/admin-auth'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

async function requireAdmin() {
  const admin = await getCurrentAdmin()
  if (!admin) return null
  return admin
}

export async function GET() {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  if (!SUPABASE_CONFIGURED) {
    const { mockLoads } = await import('@/lib/data')
    // Normalise mock loads to DbLoad shape
    const loads = mockLoads.map((l) => ({
      id: l.id,
      reference: l.id,
      origin_city: l.originCity,
      origin_country: l.originCountry,
      dest_city: l.destCity,
      dest_country: l.destCountry,
      cargo_type: l.cargoType,
      cargo_category: l.cargoCategory,
      weight_tonnes: l.weightTonnes,
      truck_type: l.truckType,
      price_amount: l.price,
      price_currency: l.currency,
      status: l.isActive ? 'active' : 'taken',
      source: l.source,
      posted_at: l.postedAt,
      updated_at: l.postedAt,
      posted_by: l.postedBy,
      negotiable: true,
      ready_date: null,
      confidence: null,
      wa_message_id: null,
      boosted_until: null,
      verification_badge: false,
    }))
    return NextResponse.json({ loads, source: 'mock' })
  }

  try {
    const { getAllLoadsAdmin } = await import('@/lib/supabase/queries')
    const loads = await getAllLoadsAdmin()
    return NextResponse.json({ loads, source: 'supabase' })
  } catch (err) {
    console.error('[admin loads GET]', err)
    return NextResponse.json({ error: 'Failed to fetch loads' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id, status } = await req.json()
  if (!id || !status) {
    return NextResponse.json({ error: 'Missing id or status' }, { status: 400 })
  }

  if (!SUPABASE_CONFIGURED) {
    return NextResponse.json({ ok: true, source: 'mock' })
  }

  try {
    const { updateLoadStatus } = await import('@/lib/supabase/queries')
    await updateLoadStatus(id, status)
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[admin loads PATCH]', err)
    return NextResponse.json({ error: 'Failed to update load' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const id = req.nextUrl.searchParams.get('id')
  if (!id) {
    return NextResponse.json({ error: 'Missing id' }, { status: 400 })
  }

  if (!SUPABASE_CONFIGURED) {
    return NextResponse.json({ ok: true, source: 'mock' })
  }

  try {
    const { deleteLoad } = await import('@/lib/supabase/queries')
    await deleteLoad(id)
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[admin loads DELETE]', err)
    return NextResponse.json({ error: 'Failed to delete load' }, { status: 500 })
  }
}
