/**
 * GET /api/admin/unlocks
 * Returns all unlock records (the "transactions" view for admins).
 * Falls back to mock transaction data when Supabase is not configured.
 */
import { NextResponse } from 'next/server'
import { getCurrentAdmin } from '@/lib/admin-auth'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

export async function GET() {
  const admin = await getCurrentAdmin()
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  if (!SUPABASE_CONFIGURED) {
    const { mockTransactions } = await import('@/lib/data')
    return NextResponse.json({ unlocks: mockTransactions, source: 'mock' })
  }

  try {
    const { getAllUnlocksAdmin } = await import('@/lib/supabase/queries')
    const unlocks = await getAllUnlocksAdmin()
    return NextResponse.json({ unlocks, source: 'supabase' })
  } catch (err) {
    console.error('[admin unlocks GET]', err)
    return NextResponse.json({ error: 'Failed to fetch unlocks' }, { status: 500 })
  }
}
