import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { getCurrentAdmin, readAdmins, writeAdmins, generateId } from '@/lib/admin-auth'
import type { AdminUser } from '@/lib/admin-auth'

// GET — list all admins (omit password hashes)
export async function GET() {
  const currentAdmin = await getCurrentAdmin()
  if (!currentAdmin) {
    return NextResponse.json({ success: false, error: 'Not authenticated.' }, { status: 401 })
  }

  const admins = readAdmins().map(({ passwordHash: _, ...rest }) => rest)
  return NextResponse.json({ success: true, admins })
}

// POST — create new admin (superadmin only)
export async function POST(req: NextRequest) {
  const currentAdmin = await getCurrentAdmin()
  if (!currentAdmin) {
    return NextResponse.json({ success: false, error: 'Not authenticated.' }, { status: 401 })
  }
  if (currentAdmin.role !== 'superadmin') {
    return NextResponse.json({ success: false, error: 'Only superadmins can add admins.' }, { status: 403 })
  }

  const { username, password, role = 'admin' } = await req.json()

  if (!username || username.trim().length < 3) {
    return NextResponse.json({ success: false, error: 'Username must be at least 3 characters.' }, { status: 400 })
  }
  if (!password || password.length < 8) {
    return NextResponse.json({ success: false, error: 'Password must be at least 8 characters.' }, { status: 400 })
  }

  const admins = readAdmins()
  if (admins.some((a) => a.username.toLowerCase() === username.toLowerCase())) {
    return NextResponse.json({ success: false, error: 'Username already exists.' }, { status: 400 })
  }

  const newAdmin: AdminUser = {
    id: generateId(),
    username: username.trim(),
    passwordHash: bcrypt.hashSync(password, 12),
    role: role === 'superadmin' ? 'superadmin' : 'admin',
    createdAt: new Date().toISOString(),
  }

  writeAdmins([...admins, newAdmin])
  const { passwordHash: _, ...safe } = newAdmin
  return NextResponse.json({ success: true, admin: safe }, { status: 201 })
}

// DELETE — remove admin by id (superadmin only, cannot delete self)
export async function DELETE(req: NextRequest) {
  const currentAdmin = await getCurrentAdmin()
  if (!currentAdmin) {
    return NextResponse.json({ success: false, error: 'Not authenticated.' }, { status: 401 })
  }
  if (currentAdmin.role !== 'superadmin') {
    return NextResponse.json({ success: false, error: 'Only superadmins can remove admins.' }, { status: 403 })
  }

  const { id } = await req.json()
  if (id === currentAdmin.id) {
    return NextResponse.json({ success: false, error: 'You cannot delete your own account.' }, { status: 400 })
  }

  const admins = readAdmins()
  const filtered = admins.filter((a) => a.id !== id)
  if (filtered.length === admins.length) {
    return NextResponse.json({ success: false, error: 'Admin not found.' }, { status: 404 })
  }

  writeAdmins(filtered)
  return NextResponse.json({ success: true })
}
