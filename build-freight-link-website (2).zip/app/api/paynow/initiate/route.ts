import { NextRequest, NextResponse } from 'next/server'
import { initiatePaynowTransaction, type PaynowConfig } from '@/lib/paynow'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    const {
      integrationId,
      integrationKey,
      returnUrl,
      resultUrl,
      merchantEmail,
      reference,
      amount,
      email,
      description,
      name,
      // Optional — passed when the unlock is for a specific load
      loadId,
      contactId,
      userFingerprint,
    } = body

    if (!integrationId || !integrationKey || !returnUrl || !resultUrl) {
      return NextResponse.json(
        { success: false, error: 'Missing Paynow credentials. Configure them in Admin Settings.' },
        { status: 400 },
      )
    }
    if (!reference || !amount || !email) {
      return NextResponse.json(
        { success: false, error: 'Missing required transaction fields.' },
        { status: 400 },
      )
    }

    const config: PaynowConfig = {
      integrationId,
      integrationKey,
      returnUrl,
      resultUrl,
      merchantEmail,
      testMode: false,
    }

    const result = await initiatePaynowTransaction({
      config,
      reference,
      amount: Number(amount),
      email,
      description,
      name,
    })

    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error }, { status: 502 })
    }

    // Write an unlock record to Supabase if DB is configured and this is a load unlock
    if (SUPABASE_CONFIGURED && loadId && contactId && userFingerprint) {
      try {
        const { createUnlock, logPaymentEvent } = await import('@/lib/supabase/queries')
        const unlock = await createUnlock({
          load_id: loadId,
          contact_id: contactId,
          user_fingerprint: userFingerprint,
          paynow_reference: reference,
          amount_usd: Number(amount),
          status: 'initiated',
          proxy_number: null,
          proxy_expires_at: null,
          watermark_tag: null,
          dispute_reason: null,
        })
        await logPaymentEvent({
          unlock_id: unlock.id,
          event_type: 'initiated',
          paynow_status: 'initiated',
          payload: { reference, amount, email, browserUrl: result.browserUrl },
        })
      } catch (dbErr) {
        // Non-fatal — payment can still proceed; log and continue
        console.error('[Paynow] failed to write unlock record:', dbErr)
      }
    }

    return NextResponse.json({
      success: true,
      browserUrl: result.browserUrl,
      pollUrl: result.pollUrl,
    })
  } catch (err) {
    console.error('[Paynow] initiate error:', err)
    return NextResponse.json({ success: false, error: 'Internal server error.' }, { status: 500 })
  }
}
