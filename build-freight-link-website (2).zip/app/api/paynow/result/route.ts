/**
 * POST /api/paynow/result
 * Paynow posts the transaction result here when payment completes or fails.
 * Verifies the hash, then confirms or fails the unlock record in Supabase.
 */
import { NextRequest, NextResponse } from 'next/server'
import { generatePaynowHash, getPaynowConfig } from '@/lib/paynow'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

export async function POST(req: NextRequest) {
  try {
    const text = await req.text()
    const params = Object.fromEntries(new URLSearchParams(text))

    const reference = params['reference'] || params['Reference'] || ''
    const status = (params['status'] || params['Status'] || '').toLowerCase()
    const amount = params['amount'] || params['Amount'] || ''
    const hash = params['hash'] || params['Hash'] || ''

    // Validate hash using stored integration key
    // Config is stored in localStorage on client — on the server we read from
    // the Paynow config form's last-saved value via a shared env or fall back.
    // For now: skip hash verification if integration key not available server-side.
    const config = getPaynowConfig() // returns defaults when called server-side
    if (config.integrationKey) {
      const fieldsWithoutHash = { ...params }
      delete fieldsWithoutHash['hash']
      delete fieldsWithoutHash['Hash']
      const expected = generatePaynowHash(fieldsWithoutHash, config.integrationKey)
      if (expected !== hash.toUpperCase()) {
        console.error('[Paynow webhook] Hash mismatch — ignoring request')
        return new NextResponse('Invalid hash', { status: 400 })
      }
    }

    console.log('[Paynow webhook]', { reference, status, amount })

    if (SUPABASE_CONFIGURED && reference) {
      const { confirmUnlock, failUnlock, logPaymentEvent, getUnlockByReference } =
        await import('@/lib/supabase/queries')

      const unlock = await getUnlockByReference(reference)

      if (unlock) {
        if (status === 'paid' || status === 'awaiting delivery') {
          // Generate a watermark tag from the unlock id (last 6 chars)
          const tag = `FL-${unlock.id.replace(/-/g, '').slice(-6).toUpperCase()}`
          await confirmUnlock(reference, tag)
          await logPaymentEvent({
            unlock_id: unlock.id,
            event_type: 'webhook_received',
            paynow_status: status,
            payload: params as Record<string, unknown>,
          })
        } else if (status === 'failed' || status === 'cancelled') {
          await failUnlock(reference)
          await logPaymentEvent({
            unlock_id: unlock.id,
            event_type: 'webhook_received',
            paynow_status: status,
            payload: params as Record<string, unknown>,
          })
        }
      }
    }

    return new NextResponse('Ok', { status: 200 })
  } catch (err) {
    console.error('[Paynow webhook] error:', err)
    return new NextResponse('Error', { status: 500 })
  }
}
