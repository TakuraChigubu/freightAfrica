/**
 * GET /api/paynow/status?reference=LOAD-xxx
 * Returns the unlock status and (if confirmed) the revealed contact details
 * for a given Paynow reference. Called by the payment return page.
 */
import { NextRequest, NextResponse } from 'next/server'

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== 'https://your-project-ref.supabase.co'

export async function GET(req: NextRequest) {
  const reference = req.nextUrl.searchParams.get('reference') ?? ''
  if (!reference) {
    return NextResponse.json({ status: 'unknown' }, { status: 400 })
  }

  if (!SUPABASE_CONFIGURED) {
    // No DB — return a demo confirmed state so the return page renders
    return NextResponse.json({
      status: 'confirmed',
      phone: '+263 77 000 0000',
      brokerName: 'Demo Contact [FL-DEMO1]',
      watermarkTag: 'FL-DEMO1',
    })
  }

  try {
    const { getUnlockByReference, getContactByLoadId } = await import('@/lib/supabase/queries')
    const unlock = await getUnlockByReference(reference)

    if (!unlock) {
      return NextResponse.json({ status: 'not_found' }, { status: 404 })
    }

    if (unlock.status === 'confirmed' || unlock.status === 'reconciled') {
      const contact = await getContactByLoadId(unlock.load_id)
      return NextResponse.json({
        status: 'confirmed',
        phone: contact?.phone_e164 ?? null,
        brokerName: contact
          ? `${contact.broker_name ?? 'Broker'} [${unlock.watermark_tag}]`
          : null,
        watermarkTag: unlock.watermark_tag,
      })
    }

    return NextResponse.json({ status: unlock.status })
  } catch (err) {
    console.error('[status] error:', err)
    return NextResponse.json({ status: 'error' }, { status: 500 })
  }
}
