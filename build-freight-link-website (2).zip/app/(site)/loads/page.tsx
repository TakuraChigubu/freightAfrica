import type { Metadata } from 'next'
import { LoadsBrowser } from '@/components/loads-browser'

export const metadata: Metadata = {
  title: 'Find Loads',
  description:
    'Browse live freight loads across the African corridor. Filter by route, truck type and cargo, or search in plain language.',
}

export default function LoadsPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 max-w-2xl">
        <h1 className="font-heading text-3xl font-700 tracking-tight sm:text-4xl">
          Find loads
        </h1>
        <p className="mt-3 text-muted-foreground">
          Live freight across the corridor. Search in plain language or filter by
          route, truck and cargo type.
        </p>
      </div>
      <LoadsBrowser />
    </div>
  )
}
