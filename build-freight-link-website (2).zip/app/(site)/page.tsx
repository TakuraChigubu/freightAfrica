import { Hero } from '@/components/home/hero'
import { Features } from '@/components/home/features'
import { PopularRoutes } from '@/components/home/routes'
import { LatestLoads } from '@/components/home/latest-loads'
import { CtaBand } from '@/components/home/cta'

export default function HomePage() {
  return (
    <>
      <Hero />
      <Features />
      <PopularRoutes />
      <LatestLoads />
      <CtaBand />
    </>
  )
}
