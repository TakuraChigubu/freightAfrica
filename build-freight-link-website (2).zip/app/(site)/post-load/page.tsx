import type { Metadata } from 'next'
import { PostLoadForm } from '@/components/post-load-form'

export const metadata: Metadata = {
  title: 'Post a Load',
  description:
    'Post your freight load to FreightLink Africa and reach drivers across the corridor instantly.',
}

export default function PostLoadPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="font-heading text-3xl font-700 tracking-tight sm:text-4xl">
          Post a load
        </h1>
        <p className="mt-3 text-muted-foreground">
          Fill in the details below to reach drivers across the African corridor.
          Your load can also be broadcast to WhatsApp and Telegram subscribers.
        </p>
      </div>
      <PostLoadForm />
    </div>
  )
}
