import type { Metadata } from 'next'
import Link from 'next/link'
import {
  PackagePlus,
  Search,
  Bot,
  MessageCircle,
  Lock,
  Truck,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

export const metadata: Metadata = {
  title: 'How It Works',
  description:
    'See how FreightLink Africa connects shippers and drivers in a few simple steps.',
}

const shipperSteps = [
  {
    icon: PackagePlus,
    title: 'Post your load',
    body: 'Add origin, destination, cargo, weight and rate in under a minute.',
  },
  {
    icon: MessageCircle,
    title: 'Reach drivers everywhere',
    body: 'Your load appears on the board and is broadcast to WhatsApp & Telegram.',
  },
  {
    icon: Truck,
    title: 'Get matched',
    body: 'Verified drivers contact you directly. No middlemen, no delays.',
  },
]

const driverSteps = [
  {
    icon: Search,
    title: 'Search loads',
    body: 'Filter by route, truck and cargo — or just describe what you want.',
  },
  {
    icon: Bot,
    title: 'Ask the AI assistant',
    body: 'Type "return load from Durban to Harare" and get instant matches.',
  },
  {
    icon: Lock,
    title: 'Unlock & go',
    body: 'Pay $1 or use your subscription to reveal contact details and book.',
  },
]

function StepList({
  steps,
  badge,
}: {
  steps: typeof shipperSteps
  badge: string
}) {
  return (
    <Card className="p-7">
      <span className="inline-flex rounded-full bg-primary/10 px-3 py-1 text-xs font-600 uppercase tracking-wider text-primary">
        {badge}
      </span>
      <ol className="mt-6 space-y-6">
        {steps.map((step, i) => (
          <li key={step.title} className="flex gap-4">
            <div className="relative flex flex-col items-center">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/20 text-accent-foreground">
                <step.icon className="h-5 w-5" />
              </div>
              {i < steps.length - 1 && (
                <span className="mt-1 h-full w-px flex-1 bg-border" aria-hidden />
              )}
            </div>
            <div className="pb-2">
              <h3 className="font-heading font-600">
                {i + 1}. {step.title}
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {step.body}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </Card>
  )
}

export default function HowItWorksPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-balance font-heading text-4xl font-800 tracking-tight">
          How FreightLink works
        </h1>
        <p className="mt-4 text-pretty text-lg text-muted-foreground">
          Whether you have cargo to move or a truck to fill, getting started
          takes minutes.
        </p>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-2">
        <StepList steps={shipperSteps} badge="For shippers" />
        <StepList steps={driverSteps} badge="For drivers" />
      </div>

      <div className="mt-12 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <Button asChild size="lg">
          <Link href="/post-load">Post a load</Link>
        </Button>
        <Button asChild size="lg" variant="outline">
          <Link href="/loads">Find loads</Link>
        </Button>
      </div>
    </div>
  )
}
