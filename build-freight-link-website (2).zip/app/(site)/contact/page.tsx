import type { Metadata } from 'next'
import { MessageCircle, Send, Mail, Phone, Clock, MapPin, CheckCircle2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import { siteConfig } from '@/lib/site'
import { ContactForm } from '@/components/contact-form'

export const metadata: Metadata = {
  title: 'Contact',
  description:
    'Get in touch with FreightLink Africa via WhatsApp, Telegram, email or our contact form.',
}

const channels = [
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    description: 'Fastest response — typically under 30 minutes during business hours.',
    action: 'Message us',
    href: siteConfig.contact.whatsapp,
    color: 'bg-[#25D366]',
    textColor: 'text-white',
    hoverColor: 'hover:bg-[#1ebc57]',
    badge: 'Recommended',
  },
  {
    icon: Send,
    label: 'Telegram',
    description: 'Join our Telegram channel for load broadcasts and platform updates.',
    action: 'Open Telegram',
    href: siteConfig.contact.telegram,
    color: 'bg-[#229ED9]',
    textColor: 'text-white',
    hoverColor: 'hover:bg-[#1a8bbf]',
    badge: null,
  },
  {
    icon: Mail,
    label: 'Email',
    description: 'For formal inquiries, partnership proposals, and billing questions.',
    action: siteConfig.contact.email,
    href: `mailto:${siteConfig.contact.email}`,
    color: 'bg-primary',
    textColor: 'text-primary-foreground',
    hoverColor: 'hover:bg-primary/90',
    badge: null,
  },
]

const officeInfo = [
  {
    icon: MapPin,
    label: 'Headquarters',
    value: 'Harare, Zimbabwe',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: siteConfig.contact.phone,
  },
  {
    icon: Clock,
    label: 'Business hours',
    value: 'Mon–Fri, 7 AM – 6 PM CAT',
  },
]

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="secondary" className="mb-4 bg-accent/10 text-accent-foreground border-accent/20">
          We respond fast
        </Badge>
        <h1 className="text-balance font-heading text-4xl font-bold tracking-tight">
          Get in touch
        </h1>
        <p className="mt-4 text-pretty text-lg text-muted-foreground">
          Whether you have a question about loads, pricing, or a business proposal —
          we&apos;re here and ready to help.
        </p>
      </div>

      {/* Contact channels */}
      <div className="mx-auto mt-14 grid max-w-4xl gap-5 sm:grid-cols-3">
        {channels.map((ch) => (
          <Card key={ch.label} className="relative flex flex-col gap-4 p-6">
            {ch.badge && (
              <Badge className="absolute -top-3 left-4 bg-accent text-accent-foreground text-xs">
                {ch.badge}
              </Badge>
            )}
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${ch.color}`}>
              <ch.icon className={`h-6 w-6 ${ch.textColor}`} />
            </div>
            <div className="flex-1">
              <p className="font-heading font-semibold text-foreground">{ch.label}</p>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{ch.description}</p>
            </div>
            <a
              href={ch.href}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${ch.color} ${ch.textColor} ${ch.hoverColor}`}
            >
              <ch.icon className="h-4 w-4" />
              {ch.action}
            </a>
          </Card>
        ))}
      </div>

      <div className="mx-auto mt-16 grid max-w-5xl gap-12 lg:grid-cols-2">
        {/* Contact form */}
        <div>
          <h2 className="font-heading text-2xl font-bold">Send a message</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Fill out the form and we&apos;ll get back to you within one business day.
          </p>
          <div className="mt-6">
            <ContactForm />
          </div>
        </div>

        {/* Office info + WhatsApp/Telegram join */}
        <div className="flex flex-col gap-8">
          <div>
            <h2 className="font-heading text-2xl font-bold">Our details</h2>
            <div className="mt-5 space-y-4">
              {officeInfo.map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
                    <p className="mt-0.5 text-sm font-medium text-foreground">{value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* WhatsApp broadcast group */}
          <Card className="overflow-hidden border-[#25D366]/30 bg-[#25D366]/5 p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#25D366]">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-heading font-semibold text-foreground">WhatsApp Load Broadcasts</p>
                <p className="text-xs text-muted-foreground">Receive new loads directly in WhatsApp</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Join our WhatsApp broadcast group to get notified of new freight loads
              on your preferred routes — straight to your phone, no app required.
            </p>
            <div className="mt-4 space-y-2">
              {[
                'Real-time load notifications',
                'Filter by route and cargo type',
                'Free to join, no subscription needed',
              ].map((item) => (
                <div key={item} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-[#25D366]" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
            <a
              href={siteConfig.contact.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#25D366] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#1ebc57]"
            >
              <MessageCircle className="h-4 w-4" />
              Join WhatsApp Broadcast
            </a>
          </Card>

          {/* Telegram channel */}
          <Card className="overflow-hidden border-[#229ED9]/30 bg-[#229ED9]/5 p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#229ED9]">
                <Send className="h-5 w-5 text-white" />
              </div>
              <div>
                <p className="font-heading font-semibold text-foreground">Telegram Channel</p>
                <p className="text-xs text-muted-foreground">Platform news and load alerts</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Our Telegram channel broadcasts freight loads and platform news to thousands
              of drivers and shippers across the African corridor.
            </p>
            <a
              href={siteConfig.contact.telegram}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#229ED9] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#1a8bbf]"
            >
              <Send className="h-4 w-4" />
              Join Telegram Channel
            </a>
          </Card>
        </div>
      </div>
    </div>
  )
}
