import type { Metadata } from "next"
import { AuthForm } from "@/components/auth-form"

export const metadata: Metadata = {
  title: "Sign In",
  description: "Sign in to your FreightLink Africa account to post and book loads across the continent.",
}

export default function LoginPage() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <AuthForm />
    </div>
  )
}
