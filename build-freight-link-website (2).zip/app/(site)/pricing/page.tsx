'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Check, Star, MessageCircle, Send, HelpCircle, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { pricingPlans, currencies } from '@/lib/data'
import { siteConfig } from '@/lib/site'
import { cn } from '@/lib/utils'
import { PaynowCheckoutModal } from '@/components/paynow-checkout-modal'

// Metadata moved — this is now a client component so metadata is handled by
// the parent layout. The page title is set via the <title> tag below.

interface CheckoutTarget {
  reference: string
  amount: number
  description: string
  tag: string
}

const faqs = [
  {
    q: 'What payment methods are supported?',
    a: 'Card payments, EcoCash, Paynow and other African mobile money options. Payment processing activates once the provider API keys are connected.',
  },
  {
    q: 'Can I switch plans later?',
    a: 'Yes. Start on pay-per-view and upgrade to monthly or annual any time. Annual saves you roughly 25% versus paying monthly.',
  },
  {
    q: 'Which currencies can I pay in?',
    a: 'USD, ZAR, ZMW, KES and NGN. Prices shown in USD are converted at checkout.',
  },
  {
    q: 'Do shippers pay to post loads?',
    a: 'Posting loads is free. Charges apply when drivers unlock a contact, or via a subscription for unlimited access.',
  },
  {
    q: 'How do I get support?',
    a: 'Reach us instantly on WhatsApp or Telegram — links are on the Contact page and at the bottom of every page.',
  },
]

export default function PricingPage() {
  const [checkoutTarget, setCheckoutTarget] = useState<CheckoutTarget | null>(null)

  function openCheckout(plan: typeof pricingPlans[number]) {
    setCheckoutTarget({
      reference: `PLAN-${plan.id}-${Date.now()}`,
      amount: plan.price,
      description: `${plan.name} — FreightLink Africa`,
      tag: plan.interval,
    })
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="secondary" className="mb-4 bg-accent/10 text-accent-foreground border-accent/20">
          Flexible pricing
        </Badge>
        <h1 className="text-balance font-heading text-4xl font-bold tracking-tight">
          Pay your way
        </h1>
        <p className="mt-4 text-pretty text-lg text-muted-foreground">
          From a single $1 unlock to unlimited fleet access. No hidden fees —
          posting loads is always free.
        </p>
      </div>

      {/* Plans */}
      <div className="mx-auto mt-14 grid max-w-5xl gap-6 lg:grid-cols-3">
        {pricingPlans.map((plan) => (
          <Card
            key={plan.id}
            className={cn(
              'relative flex flex-col p-7',
              plan.highlighted && 'border-accent shadow-xl ring-1 ring-accent',
            )}
          >
            {plan.highlighted && (
              <Badge className="absolute -top-3.5 left-1/2 -translate-x-1/2 gap-1.5 bg-accent text-accent-foreground shadow-sm">
                <Star className="h-3 w-3 fill-current" /> Most popular
              </Badge>
            )}
            <h2 className="font-heading text-lg font-semibold">{plan.name}</h2>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="font-heading text-4xl font-bold text-primary">
                {currencies[plan.currency].symbol}
                {plan.price}
              </span>
              <span className="text-sm text-muted-foreground">/ {plan.interval}</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">{plan.description}</p>

            <ul className="mt-6 flex-1 space-y-3">
              {plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-sm">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <Button
              className={cn('mt-7 w-full', plan.highlighted && 'bg-accent text-accent-foreground hover:bg-accent/90')}
              variant={plan.highlighted ? 'default' : 'outline'}
              onClick={() => openCheckout(plan)}
            >
              {plan.id === 'payg' ? 'Pay $1 to unlock' : `Choose ${plan.name}`}
            </Button>
          </Card>
        ))}
      </div>

      {/* Contact CTA */}
      <div className="mx-auto mt-16 max-w-3xl overflow-hidden rounded-2xl bg-primary px-6 py-10 text-primary-foreground sm:px-10">
        <div className="flex flex-col items-center gap-6 text-center sm:flex-row sm:text-left">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary-foreground/10">
            <Zap className="h-8 w-8 text-accent" />
          </div>
          <div className="flex-1">
            <h2 className="font-heading text-xl font-bold">Need a custom quote?</h2>
            <p className="mt-1 text-sm text-primary-foreground/80">
              Fleet operators and brokers managing 20+ loads/month get tailored rates.
              Reach us directly on WhatsApp or Telegram — we respond within the hour.
            </p>
          </div>
          <div className="flex shrink-0 flex-col gap-3 sm:flex-row">
            <Button asChild size="sm" className="gap-2 bg-[#25D366] text-white hover:bg-[#1ebc57]">
              <a href={siteConfig.contact.whatsapp} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </a>
            </Button>
            <Button asChild size="sm" className="gap-2 bg-[#229ED9] text-white hover:bg-[#1a8bbf]">
              <a href={siteConfig.contact.telegram} target="_blank" rel="noopener noreferrer">
                <Send className="h-4 w-4" />
                Telegram
              </a>
            </Button>
          </div>
        </div>
      </div>

      {/* Currency note */}
      <p className="mt-8 text-center text-sm text-muted-foreground">
        All prices shown in USD. At checkout: ZAR · ZMW · KES · NGN also accepted.
      </p>

      {/* FAQs */}
      <div className="mx-auto mt-20 max-w-3xl">
        <div className="flex items-center gap-2 text-center justify-center mb-10">
          <HelpCircle className="h-5 w-5 text-accent" />
          <h2 className="font-heading text-2xl font-bold">Frequently asked questions</h2>
        </div>
        <div className="divide-y divide-border rounded-xl border border-border overflow-hidden">
          {faqs.map(({ q, a }) => (
            <div key={q} className="px-6 py-5">
              <p className="font-heading font-semibold text-foreground">{q}</p>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{a}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="mt-16 text-center">
        <p className="text-muted-foreground">Still have questions?</p>
        <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button asChild variant="outline" className="gap-2">
            <a href={siteConfig.contact.whatsapp} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="h-4 w-4 text-[#25D366]" />
              Chat on WhatsApp
            </a>
          </Button>
          <Button asChild variant="outline" className="gap-2">
            <a href={siteConfig.contact.telegram} target="_blank" rel="noopener noreferrer">
              <Send className="h-4 w-4 text-[#229ED9]" />
              Message on Telegram
            </a>
          </Button>
          <Button asChild variant="link">
            <Link href="/contact">View all contact options</Link>
          </Button>
        </div>
      </div>

      {/* Paynow checkout modal — shared by all plan buttons */}
      {checkoutTarget && (
        <PaynowCheckoutModal
          open={checkoutTarget !== null}
          onOpenChange={(open) => { if (!open) setCheckoutTarget(null) }}
          reference={checkoutTarget.reference}
          amount={checkoutTarget.amount}
          description={checkoutTarget.description}
          tag={checkoutTarget.tag}
        />
      )}
    </div>
  )
}
