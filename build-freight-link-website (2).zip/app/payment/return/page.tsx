'use client'

import { useEffect, useState, useRef, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import {
  CheckCircle2, Clock, XCircle, Phone, Copy, ArrowLeft, Loader2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from 'sonner'

type UnlockStatus = 'loading' | 'confirmed' | 'pending' | 'failed' | 'not_found' | 'error'

interface UnlockResult {
  status: UnlockStatus
  phone?: string
  brokerName?: string
  watermarkTag?: string
}

function ReturnPageContent() {
  const searchParams = useSearchParams()
  const reference = searchParams.get('reference') ?? ''
  const [result, setResult] = useState<UnlockResult>({ status: 'loading' })
  const pollCount = useRef(0)
  const MAX_POLLS = 12 // 12 × 5 s = 60 s timeout

  useEffect(() => {
    if (!reference) {
      setResult({ status: 'error' })
      return
    }

    let cancelled = false

    async function poll() {
      if (cancelled) return
      try {
        const res = await fetch(
          `/api/paynow/status?reference=${encodeURIComponent(reference)}`,
        )
        const data = await res.json()
        if (cancelled) return

        if (data.status === 'confirmed' || data.status === 'reconciled') {
          setResult({
            status: 'confirmed',
            phone: data.phone,
            brokerName: data.brokerName,
            watermarkTag: data.watermarkTag,
          })
          return
        }

        if (data.status === 'failed' || data.status === 'cancelled') {
          setResult({ status: 'failed' })
          return
        }

        pollCount.current += 1
        if (pollCount.current < MAX_POLLS) {
          setTimeout(poll, 5000)
        } else {
          setResult({ status: 'pending' })
        }
      } catch {
        if (!cancelled) setResult({ status: 'error' })
      }
    }

    poll()
    return () => { cancelled = true }
  }, [reference])

  function copyPhone() {
    if (result.phone) {
      navigator.clipboard.writeText(result.phone)
      toast.success('Phone number copied')
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center pb-2">
          {result.status === 'loading' && (
            <>
              <Loader2 className="mx-auto h-12 w-12 animate-spin text-accent" />
              <CardTitle className="mt-4 font-heading text-xl">Confirming payment…</CardTitle>
              <p className="text-sm text-muted-foreground">
                Waiting for Paynow to confirm. This usually takes a few seconds.
              </p>
            </>
          )}
          {result.status === 'confirmed' && (
            <>
              <CheckCircle2 className="mx-auto h-12 w-12 text-green-500" />
              <CardTitle className="mt-4 font-heading text-xl">Payment confirmed</CardTitle>
              <p className="text-sm text-muted-foreground">
                Contact details are revealed below.
              </p>
            </>
          )}
          {result.status === 'pending' && (
            <>
              <Clock className="mx-auto h-12 w-12 text-yellow-500" />
              <CardTitle className="mt-4 font-heading text-xl">Still processing</CardTitle>
              <p className="text-sm text-muted-foreground">
                Your payment is still being confirmed. Refresh this page in a minute or
                contact support if the issue persists.
              </p>
            </>
          )}
          {(result.status === 'failed' ||
            result.status === 'error' ||
            result.status === 'not_found') && (
            <>
              <XCircle className="mx-auto h-12 w-12 text-destructive" />
              <CardTitle className="mt-4 font-heading text-xl">Payment not completed</CardTitle>
              <p className="text-sm text-muted-foreground">
                Your payment did not go through. No charge was made. Please try again.
              </p>
            </>
          )}
        </CardHeader>

        <CardContent className="space-y-4 pt-2">
          {result.status === 'confirmed' && result.phone && (
            <div className="rounded-xl border border-green-200 bg-green-50 p-4 dark:border-green-900 dark:bg-green-950/30">
              <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Broker contact
              </p>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 shrink-0 text-green-600" />
                  <span className="font-mono text-lg font-semibold text-foreground">
                    {result.phone}
                  </span>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={copyPhone}
                  aria-label="Copy phone number"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              {result.brokerName && (
                <p className="mt-2 text-sm text-muted-foreground">{result.brokerName}</p>
              )}
              {result.watermarkTag && (
                <p className="mt-1 font-mono text-[10px] text-muted-foreground/60">
                  Unlock ref: {result.watermarkTag}
                </p>
              )}
            </div>
          )}

          {reference && result.status !== 'confirmed' && (
            <p className="text-center font-mono text-xs text-muted-foreground">
              Ref: {reference}
            </p>
          )}

          <Button asChild variant="outline" className="w-full gap-2">
            <Link href="/loads">
              <ArrowLeft className="h-4 w-4" /> Back to loads
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

export default function PaymentReturnPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-accent" />
        </div>
      }
    >
      <ReturnPageContent />
    </Suspense>
  )
}
