/**
 * lib/supabase/queries.ts
 * ──────────────────────
 * All typed database helpers for FreightLink Africa.
 * Every function that reads or writes Supabase lives here.
 * Import the server client for RSC / API routes; the browser client for
 * client components that need real-time or optimistic updates.
 */

import { createClient } from '@/lib/supabase/server'

// ─── Types ───────────────────────────────────────────────────────────────────

export type DbLoad = {
  id: string
  reference: string
  origin_city: string
  origin_country: string
  dest_city: string
  dest_country: string
  cargo_type: string
  cargo_category: string
  weight_tonnes: number | null
  truck_type: string
  ready_date: string | null
  price_amount: number | null
  price_currency: string
  negotiable: boolean
  status: 'active' | 'taken' | 'expired' | 'review'
  confidence: number | null
  source: 'manual' | 'whatsapp' | 'telegram' | 'ai'
  wa_message_id: string | null
  posted_at: string
  updated_at: string
  boosted_until: string | null
  verification_badge: boolean
}

export type DbContact = {
  id: string
  load_id: string
  phone_e164: string
  broker_name: string | null
  whatsapp_sender: string
  broker_tier: string
  created_at: string
}

export type DbUnlock = {
  id: string
  load_id: string
  contact_id: string
  user_fingerprint: string
  paynow_reference: string
  amount_usd: number
  status: 'initiated' | 'pending' | 'confirmed' | 'failed' | 'reconciled'
  proxy_number: string | null
  proxy_expires_at: string | null
  proxy_call_count: number
  watermark_tag: string | null
  disputed: boolean
  dispute_reason: string | null
  refund_issued: boolean
  created_at: string
  confirmed_at: string | null
}

export type DbPaymentEvent = {
  id: string
  unlock_id: string
  event_type: string
  paynow_status: string | null
  payload: Record<string, unknown> | null
  created_at: string
}

// ─── Loads ───────────────────────────────────────────────────────────────────

export type LoadFilter = {
  origin_country?: string
  dest_country?: string
  truck_type?: string
  cargo_category?: string
  status?: string
  query?: string
  sort?: 'newest' | 'price-high' | 'price-low'
  limit?: number
  offset?: number
}

export async function getLoads(filter: LoadFilter = {}): Promise<DbLoad[]> {
  const supabase = await createClient()

  let q = supabase.from('loads').select('*')

  if (filter.origin_country) q = q.eq('origin_country', filter.origin_country)
  if (filter.dest_country) q = q.eq('dest_country', filter.dest_country)
  if (filter.truck_type) q = q.eq('truck_type', filter.truck_type)
  if (filter.cargo_category) q = q.eq('cargo_category', filter.cargo_category)
  if (filter.status) {
    q = q.eq('status', filter.status)
  } else {
    q = q.eq('status', 'active')
  }
  if (filter.query) {
    q = q.or(
      `origin_city.ilike.%${filter.query}%,dest_city.ilike.%${filter.query}%,cargo_type.ilike.%${filter.query}%`,
    )
  }

  if (filter.sort === 'price-high') {
    q = q.order('price_amount', { ascending: false })
  } else if (filter.sort === 'price-low') {
    q = q.order('price_amount', { ascending: true })
  } else {
    q = q.order('posted_at', { ascending: false })
  }

  q = q.limit(filter.limit ?? 100)
  if (filter.offset) q = q.range(filter.offset, filter.offset + (filter.limit ?? 100) - 1)

  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as DbLoad[]
}

export async function getLoadById(id: string): Promise<DbLoad | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('loads')
    .select('*')
    .eq('id', id)
    .single()
  if (error) return null
  return data as DbLoad
}

export async function getAllLoadsAdmin(): Promise<DbLoad[]> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('loads')
    .select('*')
    .order('posted_at', { ascending: false })
  if (error) throw error
  return (data ?? []) as DbLoad[]
}

export async function updateLoadStatus(
  id: string,
  status: DbLoad['status'],
): Promise<void> {
  const supabase = await createClient()
  const { error } = await supabase
    .from('loads')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', id)
  if (error) throw error
}

export async function deleteLoad(id: string): Promise<void> {
  const supabase = await createClient()
  const { error } = await supabase.from('loads').delete().eq('id', id)
  if (error) throw error
}

// ─── Contacts ────────────────────────────────────────────────────────────────

export async function getContactByLoadId(loadId: string): Promise<DbContact | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('contacts')
    .select('*')
    .eq('load_id', loadId)
    .single()
  if (error) return null
  return data as DbContact
}

// ─── Unlocks ─────────────────────────────────────────────────────────────────

export async function createUnlock(
  unlock: Omit<DbUnlock, 'id' | 'created_at' | 'confirmed_at' | 'proxy_call_count' | 'disputed' | 'refund_issued'>,
): Promise<DbUnlock> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('unlocks')
    .insert(unlock)
    .select()
    .single()
  if (error) throw error
  return data as DbUnlock
}

export async function getUnlockByReference(reference: string): Promise<DbUnlock | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('unlocks')
    .select('*')
    .eq('paynow_reference', reference)
    .single()
  if (error) return null
  return data as DbUnlock
}

export async function getUnlockByFingerprint(
  loadId: string,
  fingerprint: string,
): Promise<DbUnlock | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('unlocks')
    .select('*')
    .eq('load_id', loadId)
    .eq('user_fingerprint', fingerprint)
    .single()
  if (error) return null
  return data as DbUnlock
}

export async function confirmUnlock(
  reference: string,
  watermarkTag: string,
): Promise<DbUnlock | null> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('unlocks')
    .update({
      status: 'confirmed',
      confirmed_at: new Date().toISOString(),
      watermark_tag: watermarkTag,
    })
    .eq('paynow_reference', reference)
    .select()
    .single()
  if (error) return null
  return data as DbUnlock
}

export async function failUnlock(reference: string): Promise<void> {
  const supabase = await createClient()
  await supabase
    .from('unlocks')
    .update({ status: 'failed' })
    .eq('paynow_reference', reference)
}

export async function getAllUnlocksAdmin(): Promise<DbUnlock[]> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('unlocks')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data ?? []) as DbUnlock[]
}

// ─── Payment events ───────────────────────────────────────────────────────────

export async function logPaymentEvent(
  event: Omit<DbPaymentEvent, 'id' | 'created_at'>,
): Promise<void> {
  const supabase = await createClient()
  await supabase.from('payment_events').insert(event)
}

// ─── Stats (admin dashboard) ──────────────────────────────────────────────────

export type PlatformStats = {
  totalLoads: number
  activeLoads: number
  totalUnlocks: number
  confirmedUnlocks: number
  totalRevenue: number
}

export async function getPlatformStats(): Promise<PlatformStats> {
  const supabase = await createClient()

  const [loadsRes, activeRes, unlocksRes, confirmedRes] = await Promise.all([
    supabase.from('loads').select('id', { count: 'exact', head: true }),
    supabase.from('loads').select('id', { count: 'exact', head: true }).eq('status', 'active'),
    supabase.from('unlocks').select('id', { count: 'exact', head: true }),
    supabase.from('unlocks').select('amount_usd').eq('status', 'confirmed'),
  ])

  const confirmedAmounts = (confirmedRes.data ?? []) as { amount_usd: number }[]
  const totalRevenue = confirmedAmounts.reduce((sum, r) => sum + r.amount_usd, 0)

  return {
    totalLoads: loadsRes.count ?? 0,
    activeLoads: activeRes.count ?? 0,
    totalUnlocks: unlocksRes.count ?? 0,
    confirmedUnlocks: confirmedAmounts.length,
    totalRevenue,
  }
}
