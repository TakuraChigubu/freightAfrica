/**
 * Paynow Zimbabwe — server-side integration helpers.
 *
 * Flow:
 *   1. Merchant POSTs to https://www.paynow.co.zw/interface/initiatetransaction
 *      with a SHA512 hash of all fields + the integration key.
 *   2. Paynow responds with a URL-encoded string containing `browserurl`.
 *   3. Merchant redirects the customer to `browserurl`.
 *
 * Reference: https://developers.paynow.co.zw/docs/initiate_transaction.html
 */

import { createHash } from 'crypto'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface PaynowConfig {
  integrationId: string    // Numeric ID from Paynow merchant portal
  integrationKey: string   // Secret key from merchant portal
  returnUrl: string        // Where Paynow redirects the user after payment
  resultUrl: string        // Paynow POSTs result here (webhook)
  merchantEmail: string    // Registered Paynow merchant email
  testMode: boolean        // No-op flag — Paynow uses the same URL for test/live
}

export interface PaynowInitResult {
  success: true
  browserUrl: string       // Redirect the customer here
  pollUrl: string          // Poll this URL to check status
}

export interface PaynowInitError {
  success: false
  error: string
}

// ---------------------------------------------------------------------------
// Hash generation (SHA512)
// ---------------------------------------------------------------------------

/**
 * Paynow hash: SHA512 of all field values concatenated in POST order,
 * with the integration key appended at the end (uppercase hex output).
 */
export function generatePaynowHash(
  fields: Record<string, string>,
  integrationKey: string,
): string {
  const values = Object.values(fields).join('')
  return createHash('sha512')
    .update(values + integrationKey)
    .digest('hex')
    .toUpperCase()
}

// ---------------------------------------------------------------------------
// Initiate transaction
// ---------------------------------------------------------------------------

/**
 * Server-side only — never call from a Client Component.
 * POSTs to Paynow and returns the browserUrl to redirect the customer to.
 */
export async function initiatePaynowTransaction(params: {
  config: PaynowConfig
  reference: string
  amount: number          // USD, 2 decimal places
  email: string           // Payer email (required for express checkout)
  description: string
  name?: string           // Optional payer name
}): Promise<PaynowInitResult | PaynowInitError> {
  const { config, reference, amount, email, description, name } = params

  const ENDPOINT = 'https://www.paynow.co.zw/interface/initiatetransaction'

  // Build ordered fields object — order matters for the hash
  const fields: Record<string, string> = {
    id: config.integrationId,
    reference,
    amount: amount.toFixed(2),
    additionalinfo: description,
    returnurl: config.returnUrl,
    resulturl: config.resultUrl,
    status: 'Message',
  }

  if (email) fields.authemail = email
  if (name) fields.authname = name

  // Append hash (uses the key, not included in the hash value list)
  fields.hash = generatePaynowHash(fields, config.integrationKey)

  // Encode as application/x-www-form-urlencoded
  const body = new URLSearchParams(fields).toString()

  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    })

    const text = await res.text()

    // Paynow responds as a URL-encoded string: "Status=Ok&BrowserUrl=...&..."
    const parsed = Object.fromEntries(new URLSearchParams(text))

    const status = (parsed['status'] || parsed['Status'] || '').toLowerCase()

    if (status !== 'ok') {
      const errMsg = parsed['error'] || parsed['Error'] || 'Unknown error from Paynow'
      return { success: false, error: errMsg }
    }

    const browserUrl = parsed['browserurl'] || parsed['BrowserUrl']
    const pollUrl = parsed['pollurl'] || parsed['PollUrl']

    if (!browserUrl) {
      return { success: false, error: 'Paynow did not return a browser URL.' }
    }

    return { success: true, browserUrl, pollUrl: pollUrl ?? '' }
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Network error contacting Paynow.',
    }
  }
}

// ---------------------------------------------------------------------------
// Config helpers (localStorage — client only, until DB is connected)
// ---------------------------------------------------------------------------

const STORAGE_KEY = 'freightlink_paynow_config'

export const defaultPaynowConfig: PaynowConfig = {
  integrationId: '',
  integrationKey: '',
  returnUrl: '',
  resultUrl: '',
  merchantEmail: '',
  testMode: false,
}

export function getPaynowConfig(): PaynowConfig {
  if (typeof window === 'undefined') return defaultPaynowConfig
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultPaynowConfig
    return { ...defaultPaynowConfig, ...JSON.parse(raw) }
  } catch {
    return defaultPaynowConfig
  }
}

export function savePaynowConfig(config: PaynowConfig): void {
  if (typeof window === 'undefined') return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config))
}

export function isPaynowConfigured(config: PaynowConfig): boolean {
  return Boolean(config.integrationId && config.integrationKey && config.merchantEmail)
}
