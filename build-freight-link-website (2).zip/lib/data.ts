// ---------------------------------------------------------------------------
// FreightLink Africa — shared types + mock data.
//
// This is the single source of truth for the demo. When your backend APIs are
// ready, replace the exported `mockLoads`, `mockUsers`, `mockTransactions`
// arrays (and the helper getters) with real fetch calls — the UI consumes the
// types below, so swapping the data source will not require UI changes.
// ---------------------------------------------------------------------------

export type CountryCode = 'ZW' | 'ZA' | 'ZM' | 'BW' | 'MZ' | 'KE' | 'TZ' | 'NG' | 'GH'
export type CurrencyCode = 'USD' | 'ZAR' | 'ZMW' | 'KES' | 'NGN'
export type SubscriptionTier = 'free' | 'monthly' | 'annual'
export type LoadSource = 'manual' | 'whatsapp' | 'telegram' | 'ai'
export type TruckType =
  | 'Tri-axle'
  | 'Superlink'
  | 'Flatbed'
  | 'Tautliner'
  | 'Tanker'
  | 'Refrigerated'
  | 'Lowbed'
  | 'Container'

export interface Country {
  code: CountryCode
  name: string
  flag: string
}

export interface Currency {
  code: CurrencyCode
  symbol: string
  name: string
}

export interface Load {
  id: string
  originCity: string
  originCountry: CountryCode
  destCity: string
  destCountry: CountryCode
  cargoType: string
  cargoCategory: string
  weightTonnes: number
  truckType: TruckType
  price: number
  currency: CurrencyCode
  contactPhone: string
  postedBy: string
  source: LoadSource
  isActive: boolean
  postedAt: string // ISO
  expiresAt: string // ISO
}

export interface AppUser {
  id: string
  name: string
  phone: string
  country: CountryCode
  role: 'shipper' | 'driver' | 'broker'
  subscription: SubscriptionTier
  subExpiresAt: string | null
  credits: number
  createdAt: string
}

export interface Transaction {
  id: string
  userId: string
  userName: string
  loadId: string | null
  type: 'unlock' | 'subscription_monthly' | 'subscription_annual'
  amount: number
  currency: CurrencyCode
  provider: 'stripe' | 'paynow' | 'ecocash' | 'card'
  status: 'pending' | 'completed' | 'failed'
  createdAt: string
}

// --- Reference data --------------------------------------------------------

export const countries: Record<CountryCode, Country> = {
  ZW: { code: 'ZW', name: 'Zimbabwe', flag: '\u{1F1FF}\u{1F1FC}' },
  ZA: { code: 'ZA', name: 'South Africa', flag: '\u{1F1FF}\u{1F1E6}' },
  ZM: { code: 'ZM', name: 'Zambia', flag: '\u{1F1FF}\u{1F1F2}' },
  BW: { code: 'BW', name: 'Botswana', flag: '\u{1F1E7}\u{1F1FC}' },
  MZ: { code: 'MZ', name: 'Mozambique', flag: '\u{1F1F2}\u{1F1FF}' },
  KE: { code: 'KE', name: 'Kenya', flag: '\u{1F1F0}\u{1F1EA}' },
  TZ: { code: 'TZ', name: 'Tanzania', flag: '\u{1F1F9}\u{1F1FF}' },
  NG: { code: 'NG', name: 'Nigeria', flag: '\u{1F1F3}\u{1F1EC}' },
  GH: { code: 'GH', name: 'Ghana', flag: '\u{1F1EC}\u{1F1ED}' },
}

export const currencies: Record<CurrencyCode, Currency> = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar' },
  ZAR: { code: 'ZAR', symbol: 'R', name: 'South African Rand' },
  ZMW: { code: 'ZMW', symbol: 'K', name: 'Zambian Kwacha' },
  KES: { code: 'KES', symbol: 'KSh', name: 'Kenyan Shilling' },
  NGN: { code: 'NGN', symbol: '\u20A6', name: 'Nigerian Naira' },
}

export const truckTypes: TruckType[] = [
  'Tri-axle',
  'Superlink',
  'Flatbed',
  'Tautliner',
  'Tanker',
  'Refrigerated',
  'Lowbed',
  'Container',
]

export const cargoCategories = [
  'Minerals',
  'Agriculture',
  'Fuel',
  'Consumer Goods',
  'Construction',
  'Perishables',
  'Containers',
  'Livestock',
] as const

export interface PricingPlan {
  id: SubscriptionTier | 'payg'
  name: string
  price: number
  currency: CurrencyCode
  interval: string
  description: string
  features: string[]
  highlighted?: boolean
}

export const pricingPlans: PricingPlan[] = [
  {
    id: 'payg',
    name: 'Pay Per View',
    price: 1,
    currency: 'USD',
    interval: 'per contact unlock',
    description: 'Perfect for occasional drivers who only need the odd load.',
    features: [
      'Unlock a single load contact',
      'No commitment',
      'Pay with EcoCash, card or mobile money',
      'Instant access',
    ],
  },
  {
    id: 'monthly',
    name: 'Monthly',
    price: 20,
    currency: 'USD',
    interval: 'per month',
    description: 'Unlimited access for active owner-operators and brokers.',
    features: [
      'Unlimited load contact unlocks',
      'AI natural-language search',
      'WhatsApp & Telegram load alerts',
      'Priority support',
    ],
    highlighted: true,
  },
  {
    id: 'annual',
    name: 'Annual',
    price: 180,
    currency: 'USD',
    interval: 'per year',
    description: 'Best value for fleets — two months free vs monthly.',
    features: [
      'Everything in Monthly',
      'Save 25% vs paying monthly',
      'Multi-user fleet accounts',
      'Dedicated account manager',
    ],
  },
]

// --- Mock data -------------------------------------------------------------

function daysFromNow(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString()
}
function hoursAgo(hours: number): string {
  const d = new Date()
  d.setHours(d.getHours() - hours)
  return d.toISOString()
}

export const mockLoads: Load[] = [
  {
    id: 'LD-1042',
    originCity: 'Harare',
    originCountry: 'ZW',
    destCity: 'Johannesburg',
    destCountry: 'ZA',
    cargoType: 'Chrome ore',
    cargoCategory: 'Minerals',
    weightTonnes: 34,
    truckType: 'Tri-axle',
    price: 2200,
    currency: 'USD',
    contactPhone: '+263 77 000 1042',
    postedBy: 'Zimchrome Logistics',
    source: 'whatsapp',
    isActive: true,
    postedAt: hoursAgo(2),
    expiresAt: daysFromNow(6),
  },
  {
    id: 'LD-1041',
    originCity: 'Bulawayo',
    originCountry: 'ZW',
    destCity: 'Durban',
    destCountry: 'ZA',
    cargoType: 'Granite blocks',
    cargoCategory: 'Construction',
    weightTonnes: 30,
    truckType: 'Flatbed',
    price: 1950,
    currency: 'USD',
    contactPhone: '+263 71 000 1041',
    postedBy: 'Matabele Quarries',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(5),
    expiresAt: daysFromNow(6),
  },
  {
    id: 'LD-1040',
    originCity: 'Johannesburg',
    originCountry: 'ZA',
    destCity: 'Harare',
    destCountry: 'ZW',
    cargoType: 'General groceries',
    cargoCategory: 'Consumer Goods',
    weightTonnes: 28,
    truckType: 'Tautliner',
    price: 1800,
    currency: 'USD',
    contactPhone: '+27 82 000 1040',
    postedBy: 'Gauteng Distributors',
    source: 'telegram',
    isActive: true,
    postedAt: hoursAgo(8),
    expiresAt: daysFromNow(5),
  },
  {
    id: 'LD-1039',
    originCity: 'Lusaka',
    originCountry: 'ZM',
    destCity: 'Johannesburg',
    destCountry: 'ZA',
    cargoType: 'Copper cathodes',
    cargoCategory: 'Minerals',
    weightTonnes: 32,
    truckType: 'Superlink',
    price: 2600,
    currency: 'USD',
    contactPhone: '+260 97 000 1039',
    postedBy: 'Copperbelt Freight',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(12),
    expiresAt: daysFromNow(5),
  },
  {
    id: 'LD-1038',
    originCity: 'Beira',
    originCountry: 'MZ',
    destCity: 'Harare',
    destCountry: 'ZW',
    cargoType: 'Fertiliser',
    cargoCategory: 'Agriculture',
    weightTonnes: 30,
    truckType: 'Tautliner',
    price: 1500,
    currency: 'USD',
    contactPhone: '+258 84 000 1038',
    postedBy: 'Beira Port Agents',
    source: 'whatsapp',
    isActive: true,
    postedAt: hoursAgo(18),
    expiresAt: daysFromNow(4),
  },
  {
    id: 'LD-1037',
    originCity: 'Gaborone',
    originCountry: 'BW',
    destCity: 'Cape Town',
    destCountry: 'ZA',
    cargoType: 'Beef (frozen)',
    cargoCategory: 'Perishables',
    weightTonnes: 24,
    truckType: 'Refrigerated',
    price: 2100,
    currency: 'USD',
    contactPhone: '+267 71 000 1037',
    postedBy: 'Kalahari Meats',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(20),
    expiresAt: daysFromNow(4),
  },
  {
    id: 'LD-1036',
    originCity: 'Durban',
    originCountry: 'ZA',
    destCity: 'Lusaka',
    destCountry: 'ZM',
    cargoType: 'Steel coils',
    cargoCategory: 'Construction',
    weightTonnes: 33,
    truckType: 'Flatbed',
    price: 2400,
    currency: 'USD',
    contactPhone: '+27 83 000 1036',
    postedBy: 'Port Natal Steel',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(26),
    expiresAt: daysFromNow(3),
  },
  {
    id: 'LD-1035',
    originCity: 'Nairobi',
    originCountry: 'KE',
    destCity: 'Kampala',
    destCountry: 'TZ',
    cargoType: 'Tea (bagged)',
    cargoCategory: 'Agriculture',
    weightTonnes: 26,
    truckType: 'Container',
    price: 1700,
    currency: 'USD',
    contactPhone: '+254 72 000 1035',
    postedBy: 'Rift Valley Exports',
    source: 'telegram',
    isActive: true,
    postedAt: hoursAgo(30),
    expiresAt: daysFromNow(3),
  },
  {
    id: 'LD-1034',
    originCity: 'Harare',
    originCountry: 'ZW',
    destCity: 'Lusaka',
    destCountry: 'ZM',
    cargoType: 'Tobacco bales',
    cargoCategory: 'Agriculture',
    weightTonnes: 22,
    truckType: 'Tautliner',
    price: 1300,
    currency: 'USD',
    contactPhone: '+263 78 000 1034',
    postedBy: 'Tobacco Sales Floor',
    source: 'whatsapp',
    isActive: true,
    postedAt: hoursAgo(40),
    expiresAt: daysFromNow(2),
  },
  {
    id: 'LD-1033',
    originCity: 'Lagos',
    originCountry: 'NG',
    destCity: 'Accra',
    destCountry: 'GH',
    cargoType: 'Cement',
    cargoCategory: 'Construction',
    weightTonnes: 35,
    truckType: 'Tri-axle',
    price: 1900,
    currency: 'USD',
    contactPhone: '+234 80 000 1033',
    postedBy: 'West Coast Cement',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(44),
    expiresAt: daysFromNow(2),
  },
  {
    id: 'LD-1032',
    originCity: 'Johannesburg',
    originCountry: 'ZA',
    destCity: 'Bulawayo',
    destCountry: 'ZW',
    cargoType: 'Diesel',
    cargoCategory: 'Fuel',
    weightTonnes: 36,
    truckType: 'Tanker',
    price: 2300,
    currency: 'USD',
    contactPhone: '+27 84 000 1032',
    postedBy: 'Highveld Fuels',
    source: 'manual',
    isActive: true,
    postedAt: hoursAgo(50),
    expiresAt: daysFromNow(1),
  },
  {
    id: 'LD-1031',
    originCity: 'Cape Town',
    originCountry: 'ZA',
    destCity: 'Gaborone',
    destCountry: 'BW',
    cargoType: 'Wine (palletised)',
    cargoCategory: 'Consumer Goods',
    weightTonnes: 20,
    truckType: 'Tautliner',
    price: 1600,
    currency: 'USD',
    contactPhone: '+27 82 000 1031',
    postedBy: 'Cape Cellars',
    source: 'telegram',
    isActive: true,
    postedAt: hoursAgo(60),
    expiresAt: daysFromNow(1),
  },
]

export const mockUsers: AppUser[] = [
  {
    id: 'U-001',
    name: 'Tendai Moyo',
    phone: '+263 77 123 4567',
    country: 'ZW',
    role: 'driver',
    subscription: 'monthly',
    subExpiresAt: daysFromNow(18),
    credits: 0,
    createdAt: hoursAgo(720),
  },
  {
    id: 'U-002',
    name: 'Zimchrome Logistics',
    phone: '+263 77 000 1042',
    country: 'ZW',
    role: 'shipper',
    subscription: 'annual',
    subExpiresAt: daysFromNow(300),
    credits: 0,
    createdAt: hoursAgo(2160),
  },
  {
    id: 'U-003',
    name: 'Sipho Ndlovu',
    phone: '+27 82 555 9090',
    country: 'ZA',
    role: 'broker',
    subscription: 'monthly',
    subExpiresAt: daysFromNow(7),
    credits: 0,
    createdAt: hoursAgo(1440),
  },
  {
    id: 'U-004',
    name: 'Grace Banda',
    phone: '+260 97 222 3344',
    country: 'ZM',
    role: 'driver',
    subscription: 'free',
    subExpiresAt: null,
    credits: 3,
    createdAt: hoursAgo(96),
  },
  {
    id: 'U-005',
    name: 'Gauteng Distributors',
    phone: '+27 82 000 1040',
    country: 'ZA',
    role: 'shipper',
    subscription: 'free',
    subExpiresAt: null,
    credits: 0,
    createdAt: hoursAgo(48),
  },
]

export const mockTransactions: Transaction[] = [
  {
    id: 'TX-9001',
    userId: 'U-001',
    userName: 'Tendai Moyo',
    loadId: null,
    type: 'subscription_monthly',
    amount: 20,
    currency: 'USD',
    provider: 'stripe',
    status: 'completed',
    createdAt: hoursAgo(12),
  },
  {
    id: 'TX-9002',
    userId: 'U-004',
    userName: 'Grace Banda',
    loadId: 'LD-1039',
    type: 'unlock',
    amount: 1,
    currency: 'USD',
    provider: 'ecocash',
    status: 'completed',
    createdAt: hoursAgo(20),
  },
  {
    id: 'TX-9003',
    userId: 'U-002',
    userName: 'Zimchrome Logistics',
    loadId: null,
    type: 'subscription_annual',
    amount: 180,
    currency: 'USD',
    provider: 'card',
    status: 'completed',
    createdAt: hoursAgo(60),
  },
  {
    id: 'TX-9004',
    userId: 'U-005',
    userName: 'Gauteng Distributors',
    loadId: 'LD-1036',
    type: 'unlock',
    amount: 1,
    currency: 'USD',
    provider: 'paynow',
    status: 'pending',
    createdAt: hoursAgo(3),
  },
  {
    id: 'TX-9005',
    userId: 'U-003',
    userName: 'Sipho Ndlovu',
    loadId: null,
    type: 'subscription_monthly',
    amount: 20,
    currency: 'USD',
    provider: 'stripe',
    status: 'failed',
    createdAt: hoursAgo(5),
  },
]

// --- Helpers ---------------------------------------------------------------

export function formatPrice(amount: number, currency: CurrencyCode): string {
  const c = currencies[currency]
  return `${c.symbol}${amount.toLocaleString('en-US')}`
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const hours = Math.floor(diff / 3_600_000)
  if (hours < 1) return 'just now'
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}

export function getLoadById(id: string): Load | undefined {
  return mockLoads.find((l) => l.id === id)
}

export const popularRoutes = [
  { from: 'Harare', to: 'Johannesburg', fromCode: 'ZW' as const, toCode: 'ZA' as const, loads: 42 },
  { from: 'Bulawayo', to: 'Durban', fromCode: 'ZW' as const, toCode: 'ZA' as const, loads: 28 },
  { from: 'Lusaka', to: 'Johannesburg', fromCode: 'ZM' as const, toCode: 'ZA' as const, loads: 19 },
  { from: 'Beira', to: 'Harare', fromCode: 'MZ' as const, toCode: 'ZW' as const, loads: 15 },
  { from: 'Johannesburg', to: 'Harare', fromCode: 'ZA' as const, toCode: 'ZW' as const, loads: 37 },
  { from: 'Nairobi', to: 'Kampala', fromCode: 'KE' as const, toCode: 'TZ' as const, loads: 11 },
]

export const platformStats = {
  totalLoads: mockLoads.length,
  activeLoads: mockLoads.filter((l) => l.isActive).length,
  totalUsers: mockUsers.length,
  countriesCovered: Object.keys(countries).length,
  loadsThisWeek: 312,
  matchedThisWeek: 187,
}
