// Central site configuration. Swap these placeholder values for your real
// channels and credentials once they are ready.

export const siteConfig = {
  name: 'FreightLink Africa',
  tagline: 'AI-Powered Freight Load Board for Africa',
  description:
    'Post loads, find return trips, and connect shippers with drivers across the African trucking corridor.',
  url: 'https://freightlinkafrica.example', // placeholder

  // --- Contact / social channels (PLACEHOLDERS — replace with real values) ---
  contact: {
    email: 'hello@freightlinkafrica.example',
    phone: '+263 00 000 0000',
    // WhatsApp: use the wa.me format with full international number, no "+"
    whatsapp: 'https://wa.me/263000000000',
    // Telegram: your bot or channel handle
    telegram: 'https://t.me/freightlinkafrica',
  },
} as const

export const mainNav = [
  { title: 'Home', href: '/' },
  { title: 'Find Loads', href: '/loads' },
  { title: 'Post a Load', href: '/post-load' },
  { title: 'Pricing', href: '/pricing' },
  { title: 'How It Works', href: '/how-it-works' },
  { title: 'Contact', href: '/contact' },
] as const
