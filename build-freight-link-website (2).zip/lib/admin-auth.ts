/**
 * Admin authentication helpers.
 *
 * Credentials are stored in data/admins.json as bcrypt-hashed passwords.
 * The session is a signed token stored in an HttpOnly cookie.
 *
 * File format (data/admins.json):
 * [
 *   { "id": "1", "username": "admin", "passwordHash": "$2b$12$...", "role": "superadmin" }
 * ]
 */

import { readFileSync, writeFileSync, existsSync } from 'fs'
import { join } from 'path'
import { createHmac, randomBytes } from 'crypto'
import bcrypt from 'bcryptjs'
import { cookies } from 'next/headers'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AdminUser {
  id: string
  username: string
  passwordHash: string
  role: 'superadmin' | 'admin'
  createdAt: string
}

// ---------------------------------------------------------------------------
// File store
// ---------------------------------------------------------------------------

const DATA_PATH = join(process.cwd(), 'data', 'admins.json')

export function readAdmins(): AdminUser[] {
  if (!existsSync(DATA_PATH)) {
    // Seed with default superadmin (password: "admin123" — user must change it)
    const seed: AdminUser[] = [
      {
        id: '1',
        username: 'admin',
        passwordHash: bcrypt.hashSync('admin123', 12),
        role: 'superadmin',
        createdAt: new Date().toISOString(),
      },
    ]
    writeFileSync(DATA_PATH, JSON.stringify(seed, null, 2), 'utf8')
    return seed
  }
  try {
    return JSON.parse(readFileSync(DATA_PATH, 'utf8')) as AdminUser[]
  } catch {
    return []
  }
}

export function writeAdmins(admins: AdminUser[]): void {
  writeFileSync(DATA_PATH, JSON.stringify(admins, null, 2), 'utf8')
}

// ---------------------------------------------------------------------------
// Session (signed HMAC cookie, no DB needed)
// ---------------------------------------------------------------------------

const SESSION_COOKIE = 'fla_admin_session'
const SECRET = process.env.ADMIN_SESSION_SECRET ?? 'freightlink-africa-admin-secret-change-me'

function sign(payload: string): string {
  const sig = createHmac('sha256', SECRET).update(payload).digest('hex')
  return `${payload}.${sig}`
}

function verify(token: string): string | null {
  const lastDot = token.lastIndexOf('.')
  if (lastDot === -1) return null
  const payload = token.slice(0, lastDot)
  const sig = token.slice(lastDot + 1)
  const expected = createHmac('sha256', SECRET).update(payload).digest('hex')
  if (sig !== expected) return null
  return payload
}

export async function createSession(userId: string): Promise<void> {
  const payload = `${userId}:${Date.now()}`
  const token = sign(payload)
  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 8, // 8 hours
  })
}

export async function getSessionUserId(): Promise<string | null> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return null
  const payload = verify(token)
  if (!payload) return null
  const [userId] = payload.split(':')
  return userId || null
}

export async function destroySession(): Promise<void> {
  const jar = await cookies()
  jar.delete(SESSION_COOKIE)
}

export async function getCurrentAdmin(): Promise<AdminUser | null> {
  const userId = await getSessionUserId()
  if (!userId) return null
  const admins = readAdmins()
  return admins.find((a) => a.id === userId) ?? null
}

// ---------------------------------------------------------------------------
// Auth logic
// ---------------------------------------------------------------------------

export async function loginAdmin(
  username: string,
  password: string,
): Promise<{ success: true; user: AdminUser } | { success: false; error: string }> {
  const admins = readAdmins()
  const user = admins.find((a) => a.username.toLowerCase() === username.toLowerCase())
  if (!user) return { success: false, error: 'Invalid username or password.' }

  const match = await bcrypt.compare(password, user.passwordHash)
  if (!match) return { success: false, error: 'Invalid username or password.' }

  await createSession(user.id)
  return { success: true, user }
}

export function generateId(): string {
  return randomBytes(6).toString('hex')
}
