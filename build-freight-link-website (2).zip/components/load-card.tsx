'use client'

import { useState } from 'react'
import { ArrowRight, Truck, Weight, Lock, Clock } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { PaynowCheckoutModal } from '@/components/paynow-checkout-modal'
import { type Load, countries, formatPrice, timeAgo } from '@/lib/data'
import { cn } from '@/lib/utils'

const sourceStyles: Record<string, string> = {
  whatsapp: 'bg-[oklch(0.65_0.13_145)]/15 text-[oklch(0.45_0.13_145)]',
  telegram: 'bg-[oklch(0.55_0.1_230)]/15 text-[oklch(0.45_0.1_230)]',
  ai: 'bg-accent/20 text-accent-foreground',
  manual: 'bg-secondary text-secondary-foreground',
}

export function LoadCard({ load }: { load: Load }) {
  const [checkoutOpen, setCheckoutOpen] = useState(false)
  const origin = countries[load.originCountry]
  const dest = countries[load.destCountry]

  return (
    <>
      <Card className="flex flex-col gap-4 p-5 transition-shadow hover:shadow-md">
        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="font-mono">{load.id}</span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" /> {timeAgo(load.postedAt)}
            </span>
          </div>
          <Badge
            variant="secondary"
            className={cn('capitalize', sourceStyles[load.source])}
          >
            {load.source}
          </Badge>
        </div>

        {/* Route */}
        <div className="flex items-center gap-3">
          <div className="min-w-0">
            <p className="truncate font-heading text-base font-semibold">{load.originCity}</p>
            <p className="text-xs text-muted-foreground">
              {origin.flag} {origin.name}
            </p>
          </div>
          <ArrowRight className="h-5 w-5 shrink-0 text-accent" />
          <div className="min-w-0">
            <p className="truncate font-heading text-base font-semibold">{load.destCity}</p>
            <p className="text-xs text-muted-foreground">
              {dest.flag} {dest.name}
            </p>
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="font-normal">
            {load.cargoType}
          </Badge>
          <Badge variant="outline" className="gap-1 font-normal">
            <Truck className="h-3 w-3" /> {load.truckType}
          </Badge>
          <Badge variant="outline" className="gap-1 font-normal">
            <Weight className="h-3 w-3" /> {load.weightTonnes}t
          </Badge>
        </div>

        {/* Footer */}
        <div className="mt-auto flex items-center justify-between border-t border-border pt-4">
          <div>
            <p className="font-heading text-xl font-bold text-primary">
              {formatPrice(load.price, load.currency)}
            </p>
            <p className="text-xs text-muted-foreground">{load.currency} · est. rate</p>
          </div>
          <Button
            size="sm"
            className="gap-1.5 bg-accent text-accent-foreground hover:bg-accent/90"
            onClick={() => setCheckoutOpen(true)}
          >
            <Lock className="h-3.5 w-3.5" />
            Unlock for $1
          </Button>
        </div>
      </Card>

      {/* Paynow checkout modal */}
      <PaynowCheckoutModal
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        reference={`LOAD-${load.id}-${Date.now()}`}
        amount={1}
        description={`Unlock contact — ${load.cargoType}, ${load.originCity} → ${load.destCity}`}
        tag="Pay-per-view"
      />
    </>
  )
}
