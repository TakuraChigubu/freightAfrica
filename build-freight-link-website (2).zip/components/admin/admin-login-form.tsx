'use client'

import { useState } from 'react'
import { Eye, EyeOff, Loader2, Lock, User } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

export function AdminLoginForm() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')

    if (!username.trim() || !password) {
      setError('Both username and password are required.')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      })
      const data = await res.json()

      if (!data.success) {
        setError(data.error ?? 'Login failed.')
        return
      }

      toast.success('Welcome back!')
      // Hard navigation ensures the new session cookie is included in the request
      window.location.href = '/admin'
    } catch {
      setError('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-1.5">
        <Label className="text-sidebar-foreground flex items-center gap-1.5">
          <User className="h-3.5 w-3.5 opacity-60" />
          Username
        </Label>
        <Input
          value={username}
          onChange={(e) => { setUsername(e.target.value); setError('') }}
          placeholder="admin"
          autoComplete="username"
          disabled={loading}
          className="bg-sidebar border-sidebar-border text-sidebar-foreground placeholder:text-sidebar-foreground/30"
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-sidebar-foreground flex items-center gap-1.5">
          <Lock className="h-3.5 w-3.5 opacity-60" />
          Password
        </Label>
        <div className="relative">
          <Input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => { setPassword(e.target.value); setError('') }}
            placeholder="••••••••"
            autoComplete="current-password"
            disabled={loading}
            className="bg-sidebar border-sidebar-border pr-10 text-sidebar-foreground placeholder:text-sidebar-foreground/30"
          />
          <button
            type="button"
            className="absolute right-3 top-1/2 -translate-y-1/2 text-sidebar-foreground/40 hover:text-sidebar-foreground transition-colors"
            onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? 'Hide password' : 'Show password'}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {error && (
        <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}

      <Button
        type="submit"
        className="w-full gap-2 bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90"
        disabled={loading}
      >
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
        {loading ? 'Signing in...' : 'Sign in'}
      </Button>

      <p className="text-center text-xs text-sidebar-foreground/40">
        Default credentials: admin / admin123
        <br />
        Change your password after first login.
      </p>
    </form>
  )
}
