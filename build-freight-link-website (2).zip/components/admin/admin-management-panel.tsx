'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Trash2, Plus, Eye, EyeOff, Loader2, CheckCircle,
  ShieldCheck, Shield, Key, UserPlus
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

// ---------------------------------------------------------------------------
// Types (mirror server)
// ---------------------------------------------------------------------------

interface AdminRow {
  id: string
  username: string
  role: 'superadmin' | 'admin'
  createdAt: string
}

// ---------------------------------------------------------------------------
// Subcomponent — Change own password
// ---------------------------------------------------------------------------

function ChangePasswordForm() {
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showCurrent, setShowCurrent] = useState(false)
  const [showNext, setShowNext] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!current || !next || !confirm) { setError('All fields are required.'); return }
    if (next.length < 8) { setError('New password must be at least 8 characters.'); return }
    if (next !== confirm) { setError('New passwords do not match.'); return }

    setLoading(true)
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      })
      const data = await res.json()
      if (!data.success) { setError(data.error ?? 'Failed.'); return }
      toast.success('Password changed successfully.')
      setCurrent(''); setNext(''); setConfirm('')
    } catch { setError('Network error.') }
    finally { setLoading(false) }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label>Current password</Label>
          <div className="relative">
            <Input
              type={showCurrent ? 'text' : 'password'}
              value={current}
              onChange={(e) => { setCurrent(e.target.value); setError('') }}
              placeholder="••••••••"
              autoComplete="current-password"
              disabled={loading}
              className="pr-10"
            />
            <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowCurrent(v => !v)} aria-label={showCurrent ? 'Hide' : 'Show'}>
              {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>New password</Label>
          <div className="relative">
            <Input
              type={showNext ? 'text' : 'password'}
              value={next}
              onChange={(e) => { setNext(e.target.value); setError('') }}
              placeholder="8+ characters"
              autoComplete="new-password"
              disabled={loading}
              className="pr-10"
            />
            <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowNext(v => !v)} aria-label={showNext ? 'Hide' : 'Show'}>
              {showNext ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Confirm new password</Label>
          <Input
            type="password"
            value={confirm}
            onChange={(e) => { setConfirm(e.target.value); setError('') }}
            placeholder="Repeat new password"
            autoComplete="new-password"
            disabled={loading}
          />
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <Button type="submit" className="gap-2" disabled={loading}>
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Key className="h-4 w-4" />}
        {loading ? 'Saving...' : 'Change password'}
      </Button>
    </form>
  )
}

// ---------------------------------------------------------------------------
// Subcomponent — Add new admin
// ---------------------------------------------------------------------------

function AddAdminForm({ onAdded }: { onAdded: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<'admin' | 'superadmin'>('admin')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (username.trim().length < 3) { setError('Username must be at least 3 characters.'); return }
    if (password.length < 8) { setError('Password must be at least 8 characters.'); return }

    setLoading(true)
    try {
      const res = await fetch('/api/admin/admins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password, role }),
      })
      const data = await res.json()
      if (!data.success) { setError(data.error ?? 'Failed.'); return }
      toast.success(`Admin "${username.trim()}" added.`)
      setUsername(''); setPassword('')
      onAdded()
    } catch { setError('Network error.') }
    finally { setLoading(false) }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label>Username</Label>
          <Input
            value={username}
            onChange={(e) => { setUsername(e.target.value); setError('') }}
            placeholder="e.g. johndoe"
            disabled={loading}
          />
        </div>
        <div className="space-y-1.5">
          <Label>Password</Label>
          <div className="relative">
            <Input
              type={showPw ? 'text' : 'password'}
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError('') }}
              placeholder="8+ characters"
              disabled={loading}
              className="pr-10"
            />
            <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowPw(v => !v)} aria-label={showPw ? 'Hide' : 'Show'}>
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Role</Label>
          <div className="flex gap-2 pt-1">
            {(['admin', 'superadmin'] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={`flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-medium transition-colors ${
                  role === r
                    ? 'border-accent bg-accent/10 text-accent-foreground'
                    : 'border-border text-muted-foreground hover:border-accent/50'
                }`}
              >
                {r === 'superadmin'
                  ? <ShieldCheck className="h-3.5 w-3.5" />
                  : <Shield className="h-3.5 w-3.5" />}
                {r === 'superadmin' ? 'Superadmin' : 'Admin'}
              </button>
            ))}
          </div>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      <Button type="submit" variant="outline" className="gap-2" disabled={loading}>
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
        {loading ? 'Adding...' : 'Add admin'}
      </Button>
    </form>
  )
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export function AdminManagementPanel() {
  const [admins, setAdmins] = useState<AdminRow[]>([])
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const fetchAdmins = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/admins')
      const data = await res.json()
      if (data.success) setAdmins(data.admins)
    } catch {
      toast.error('Could not load admin list.')
    }
  }, [])

  useEffect(() => { fetchAdmins() }, [fetchAdmins])

  async function handleDelete(id: string, username: string) {
    if (!confirm(`Remove admin "${username}"? This cannot be undone.`)) return
    setDeletingId(id)
    try {
      const res = await fetch('/api/admin/admins', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      const data = await res.json()
      if (!data.success) { toast.error(data.error ?? 'Failed.'); return }
      toast.success(`Admin "${username}" removed.`)
      fetchAdmins()
    } catch { toast.error('Network error.') }
    finally { setDeletingId(null) }
  }

  return (
    <div className="space-y-8">
      {/* Change own password */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-foreground flex items-center gap-2">
          <Key className="h-4 w-4 text-accent" />
          Change your password
        </h3>
        <ChangePasswordForm />
      </div>

      <Separator />

      {/* Admin list */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-foreground flex items-center gap-2">
          <Shield className="h-4 w-4 text-accent" />
          All admins
        </h3>
        <div className="space-y-2">
          {admins.length === 0 && (
            <p className="text-sm text-muted-foreground">Loading...</p>
          )}
          {admins.map((a) => (
            <div
              key={a.id}
              className="flex items-center justify-between rounded-lg border border-border bg-muted/20 px-4 py-3"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold uppercase text-sidebar-primary-foreground">
                  {a.username.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium">{a.username}</p>
                  <p className="text-xs text-muted-foreground">
                    Added {new Date(a.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={
                    a.role === 'superadmin'
                      ? 'border-accent/40 text-accent-foreground gap-1'
                      : 'gap-1'
                  }
                >
                  {a.role === 'superadmin'
                    ? <ShieldCheck className="h-3 w-3" />
                    : <Shield className="h-3 w-3" />}
                  {a.role === 'superadmin' ? 'Superadmin' : 'Admin'}
                </Badge>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  onClick={() => handleDelete(a.id, a.username)}
                  disabled={deletingId === a.id}
                  aria-label={`Remove ${a.username}`}
                >
                  {deletingId === a.id
                    ? <Loader2 className="h-4 w-4 animate-spin" />
                    : <Trash2 className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Add admin */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-foreground flex items-center gap-2">
          <Plus className="h-4 w-4 text-accent" />
          Add admin
        </h3>
        <AddAdminForm onAdded={fetchAdmins} />
      </div>
    </div>
  )
}
