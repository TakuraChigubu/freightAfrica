import type { LucideIcon } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface StatCardProps {
  label: string
  value: string | number
  icon: LucideIcon
  hint?: string
}

export function StatCard({ label, value, icon: Icon, hint }: StatCardProps) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-5">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-6 w-6" />
        </div>
        <div className="min-w-0">
          <p className="text-2xl font-bold leading-tight text-foreground">{value}</p>
          <p className="truncate text-sm text-muted-foreground">{label}</p>
          {hint ? <p className="text-xs text-muted-foreground/70">{hint}</p> : null}
        </div>
      </CardContent>
    </Card>
  )
}
