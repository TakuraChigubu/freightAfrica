"use client"

import { useEffect, useState, useMemo, useCallback } from "react"
import { Search, MoreHorizontal, Trash2, Eye, EyeOff, Loader2, RefreshCw } from "lucide-react"
import { toast } from "sonner"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { countries, formatPrice, timeAgo } from "@/lib/data"
import type { DbLoad } from "@/lib/supabase/queries"

// Extend DbLoad with optional posted_by that mock route adds
type AdminLoad = DbLoad & { posted_by?: string }

const STATUS_VARIANT: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
  active: "default",
  review: "secondary",
  taken: "outline",
  expired: "destructive",
}

export function AdminLoadsTable() {
  const [loads, setLoads] = useState<AdminLoad[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState("")
  const [source, setSource] = useState("all")

  const fetchLoads = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/admin/loads")
      const json = await res.json()
      setLoads(json.loads ?? [])
    } catch {
      toast.error("Failed to load data")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchLoads() }, [fetchLoads])

  const filtered = useMemo(() => {
    return loads.filter((l) => {
      const matchesQuery =
        query === "" ||
        `${l.origin_city} ${l.dest_city} ${l.cargo_type} ${l.posted_by ?? ""} ${l.reference}`
          .toLowerCase()
          .includes(query.toLowerCase())
      const matchesSource = source === "all" || l.source === source
      return matchesQuery && matchesSource
    })
  }, [loads, query, source])

  async function updateStatus(id: string, newStatus: DbLoad["status"]) {
    const prev = loads
    setLoads((ls) => ls.map((l) => (l.id === id ? { ...l, status: newStatus } : l)))
    try {
      const res = await fetch("/api/admin/loads", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: newStatus }),
      })
      if (!res.ok) throw new Error("Failed")
      toast.success("Load status updated")
    } catch {
      setLoads(prev)
      toast.error("Failed to update load")
    }
  }

  async function removeLoad(id: string, reference: string) {
    const prev = loads
    setLoads((ls) => ls.filter((l) => l.id !== id))
    try {
      const res = await fetch(`/api/admin/loads?id=${id}`, { method: "DELETE" })
      if (!res.ok) throw new Error("Failed")
      toast.success(`Load ${reference} removed`)
    } catch {
      setLoads(prev)
      toast.error("Failed to remove load")
    }
  }

  function getCountry(code: string) {
    return countries[code as keyof typeof countries] ?? { flag: "", name: code }
  }

  return (
    <Card className="p-4">
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search loads by route, cargo, ID..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={source} onValueChange={(v) => setSource(v ?? "all")}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All sources</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
            <SelectItem value="whatsapp">WhatsApp</SelectItem>
            <SelectItem value="telegram">Telegram</SelectItem>
            <SelectItem value="ai">AI</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="icon" onClick={fetchLoads} aria-label="Refresh">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Ref</TableHead>
              <TableHead>Route</TableHead>
              <TableHead className="hidden md:table-cell">Cargo</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-10" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="py-12 text-center">
                  <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-muted-foreground">
                  No loads match your filters.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((load) => {
                const orig = getCountry(load.origin_country)
                const dest = getCountry(load.dest_country)
                const isActive = load.status === "active"
                return (
                  <TableRow key={load.id}>
                    <TableCell className="font-mono text-xs">{load.reference}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {load.origin_city} {orig.flag} → {load.dest_city} {dest.flag}
                      <span className="block text-xs text-muted-foreground">
                        {timeAgo(load.posted_at)}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {load.cargo_type}
                      <span className="block text-xs text-muted-foreground">
                        {load.weight_tonnes ? `${load.weight_tonnes}t · ` : ""}
                        {load.truck_type}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {load.source}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-semibold">
                      {load.price_amount
                        ? formatPrice(load.price_amount, load.price_currency as "USD")
                        : "—"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={STATUS_VARIANT[load.status] ?? "outline"} className="capitalize">
                        {load.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() =>
                              updateStatus(load.id, isActive ? "taken" : "active")
                            }
                          >
                            {isActive ? (
                              <><EyeOff className="mr-2 h-4 w-4" /> Mark as taken</>
                            ) : (
                              <><Eye className="mr-2 h-4 w-4" /> Mark as active</>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() =>
                              updateStatus(load.id, load.status === "review" ? "active" : "review")
                            }
                          >
                            {load.status === "review" ? "Remove review flag" : "Flag for review"}
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => removeLoad(load.id, load.reference)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete load
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
      <div className="border-t border-border px-1 pt-3 text-xs text-muted-foreground">
        Showing {filtered.length} of {loads.length} loads
      </div>
    </Card>
  )
}
