'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname, useRouter } from 'next/navigation'
import { Menu, X, LayoutDashboard, Package, Users, Receipt, Settings, Globe, LogOut, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

const nav = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard, exact: true },
  { href: '/admin/loads', label: 'Loads', icon: Package, exact: false },
  { href: '/admin/users', label: 'Users', icon: Users, exact: false },
  { href: '/admin/transactions', label: 'Transactions', icon: Receipt, exact: false },
  { href: '/admin/settings', label: 'Settings', icon: Settings, exact: false },
]

interface AdminMobileHeaderProps {
  currentAdmin: { username: string; role: string }
}

export function AdminMobileHeader({ currentAdmin }: AdminMobileHeaderProps) {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  function isActive(item: (typeof nav)[number]) {
    return item.exact ? pathname === item.href : pathname.startsWith(item.href)
  }

  async function handleSignOut() {
    await fetch('/api/admin/logout', { method: 'POST' })
    router.push('/admin/login')
    router.refresh()
  }

  const currentPage = nav.find((i) => isActive(i))?.label ?? 'Admin'

  return (
    <>
      <header className="flex h-14 items-center justify-between border-b border-border bg-sidebar px-4 text-sidebar-foreground lg:hidden">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg bg-white">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%20Jun%2028%2C%202026%2C%2009_11_04%20PM-1wLIdcjf7uQBOAfry1fnBxuBHMKt8h.png"
              alt="FreightLink Africa"
              width={28}
              height={28}
              className="object-contain"
            />
          </div>
          <span className="font-heading text-sm font-bold">{currentPage}</span>
        </div>
        <button
          onClick={() => setOpen(true)}
          aria-label="Open menu"
          className="rounded-lg p-2 hover:bg-sidebar-accent"
        >
          <Menu className="h-5 w-5" />
        </button>
      </header>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 flex h-full w-64 flex-col bg-sidebar text-sidebar-foreground shadow-xl">
            <div className="flex h-14 items-center justify-between border-b border-sidebar-border px-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg bg-white">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%20Jun%2028%2C%202026%2C%2009_11_04%20PM-1wLIdcjf7uQBOAfry1fnBxuBHMKt8h.png"
                    alt="FreightLink Africa"
                    width={28}
                    height={28}
                    className="object-contain"
                  />
                </div>
                <p className="font-heading text-sm font-bold">Admin Panel</p>
              </div>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="rounded-lg p-1.5 hover:bg-sidebar-accent"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <nav className="flex-1 space-y-0.5 p-3" aria-label="Mobile admin navigation">
              {nav.map((item) => {
                const active = isActive(item)
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={cn(
                      'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                      active
                        ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                        : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                    )}
                  >
                    <item.icon className="h-4 w-4 shrink-0" />
                    <span className="flex-1">{item.label}</span>
                    {active && <ChevronRight className="h-3.5 w-3.5 opacity-60" />}
                  </Link>
                )
              })}
            </nav>

            <div className="border-t border-sidebar-border p-3 space-y-0.5">
              <Link
                href="/"
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                onClick={() => setOpen(false)}
              >
                <Globe className="h-4 w-4 shrink-0" />
                View site
              </Link>
              {/* User badge */}
              <div className="flex items-center gap-2.5 rounded-lg px-3 py-2 mb-1">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold text-sidebar-primary-foreground uppercase">
                  {currentAdmin.username.charAt(0)}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-sidebar-foreground">{currentAdmin.username}</p>
                  <p className="text-[10px] text-sidebar-foreground/50 uppercase tracking-wider">{currentAdmin.role}</p>
                </div>
              </div>
              <button
                onClick={handleSignOut}
                className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <LogOut className="h-4 w-4 shrink-0" />
                Sign out
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
