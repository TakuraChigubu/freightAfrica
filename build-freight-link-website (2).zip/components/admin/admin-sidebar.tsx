"use client"

import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Package, Users, Receipt, Settings, Globe, LogOut, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

const nav = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/admin/loads", label: "Loads", icon: Package, exact: false },
  { href: "/admin/users", label: "Users", icon: Users, exact: false },
  { href: "/admin/transactions", label: "Transactions", icon: Receipt, exact: false },
  { href: "/admin/settings", label: "Settings", icon: Settings, exact: false },
]

interface AdminSidebarProps {
  currentAdmin: { username: string; role: string }
}

export function AdminSidebar({ currentAdmin }: AdminSidebarProps) {
  const pathname = usePathname()
  const router = useRouter()

  function isActive(item: (typeof nav)[number]) {
    return item.exact ? pathname === item.href : pathname.startsWith(item.href)
  }

  async function handleSignOut() {
    await fetch('/api/admin/logout', { method: 'POST' })
    router.push('/admin/login')
    router.refresh()
  }

  return (
    <aside className="flex h-full w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%20Jun%2028%2C%202026%2C%2009_11_04%20PM-1wLIdcjf7uQBOAfry1fnBxuBHMKt8h.png"
            alt="FreightLink Africa"
            width={36}
            height={36}
            className="object-contain"
          />
        </div>
        <div className="min-w-0">
          <p className="font-heading text-sm font-bold leading-tight">FreightLink</p>
          <p className="text-[10px] text-sidebar-foreground/60 uppercase tracking-wider">Admin Panel</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-0.5 p-3" aria-label="Admin navigation">
        {nav.map((item) => {
          const active = isActive(item)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                active
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {active && <ChevronRight className="h-3.5 w-3.5 opacity-60" />}
            </Link>
          )
        })}
      </nav>

      {/* Current user + bottom actions */}
      <div className="border-t border-sidebar-border p-3 space-y-0.5">
        {/* User badge */}
        <div className="flex items-center gap-2.5 rounded-lg px-3 py-2 mb-1">
          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold text-sidebar-primary-foreground uppercase">
            {currentAdmin.username.charAt(0)}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-sidebar-foreground">{currentAdmin.username}</p>
            <p className="text-[10px] text-sidebar-foreground/50 uppercase tracking-wider">{currentAdmin.role}</p>
          </div>
        </div>

        <Link
          href="/"
          className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        >
          <Globe className="h-4 w-4 shrink-0" />
          View site
        </Link>
        <button
          onClick={handleSignOut}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        >
          <LogOut className="h-4 w-4 shrink-0" />
          Sign out
        </button>
      </div>
    </aside>
  )
}
