'use client'

import { useEffect, useState, useMemo, useCallback } from 'react'
import { Search, RefreshCw, Loader2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatPrice, timeAgo } from '@/lib/data'
import type { DbUnlock } from '@/lib/supabase/queries'
import type { Transaction } from '@/lib/data'
import { toast } from 'sonner'

// Unified view row — works with both DbUnlock (Supabase) and mock Transaction
interface TxRow {
  id: string
  userLabel: string
  typeLabel: string
  provider: string
  amount: number
  currency: string
  status: string
  createdAt: string
  loadRef: string | null
}

function fromUnlock(u: DbUnlock): TxRow {
  return {
    id: u.id,
    userLabel: u.user_fingerprint.slice(0, 10) + '…',
    typeLabel: 'unlock',
    provider: 'paynow',
    amount: u.amount_usd,
    currency: 'USD',
    status: u.status,
    createdAt: u.created_at,
    loadRef: u.load_id,
  }
}

function fromMockTx(t: Transaction): TxRow {
  return {
    id: t.id,
    userLabel: t.userName,
    typeLabel: t.type.replace(/_/g, ' '),
    provider: t.provider,
    amount: t.amount,
    currency: t.currency,
    status: t.status,
    createdAt: t.createdAt,
    loadRef: t.loadId,
  }
}

function normalise(raw: (DbUnlock | Transaction)[]): TxRow[] {
  return raw.map((item) => {
    // DbUnlock has amount_usd; Transaction has amount
    if ('amount_usd' in item) return fromUnlock(item as DbUnlock)
    return fromMockTx(item as Transaction)
  })
}

const STATUS_VARIANT: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  confirmed: 'default',
  completed: 'default',
  reconciled: 'default',
  pending: 'secondary',
  initiated: 'secondary',
  failed: 'destructive',
  cancelled: 'destructive',
}

const PROVIDER_LABEL: Record<string, string> = {
  stripe: 'Stripe',
  paynow: 'Paynow',
  ecocash: 'EcoCash',
  card: 'Card',
}

export function AdminTransactionsTable() {
  const [rows, setRows] = useState<TxRow[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/unlocks')
      const json = await res.json()
      const raw: (DbUnlock | Transaction)[] = json.unlocks ?? []
      setRows(normalise(raw))
    } catch {
      toast.error('Failed to load transactions')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  const filtered = useMemo(() => {
    let result = rows
    if (query) {
      const q = query.toLowerCase()
      result = result.filter(
        (r) =>
          r.userLabel.toLowerCase().includes(q) ||
          r.typeLabel.includes(q) ||
          r.provider.includes(q) ||
          (r.loadRef ?? '').toLowerCase().includes(q),
      )
    }
    if (statusFilter !== 'all') result = result.filter((r) => r.status === statusFilter)
    return result
  }, [rows, query, statusFilter])

  const confirmedRows = rows.filter((r) =>
    r.status === 'confirmed' || r.status === 'completed' || r.status === 'reconciled',
  )
  const totalRevenue = confirmedRows.reduce((sum, r) => sum + r.amount, 0)
  const pendingCount = rows.filter((r) => r.status === 'pending' || r.status === 'initiated').length

  return (
    <div className="flex flex-col gap-4">
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total revenue (USD)', value: `$${totalRevenue.toFixed(0)}` },
          { label: 'Confirmed', value: confirmedRows.length },
          { label: 'Pending', value: pendingCount },
        ].map(({ label, value }) => (
          <Card key={label} className="p-4">
            <p className="text-2xl font-bold text-foreground">{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </Card>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by user, type, provider..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-2">
          {['all', 'confirmed', 'pending', 'failed'].map((s) => (
            <Button
              key={s}
              size="sm"
              variant={statusFilter === s ? 'default' : 'outline'}
              onClick={() => setStatusFilter(s)}
              className="capitalize"
            >
              {s}
            </Button>
          ))}
          <Button variant="outline" size="icon" onClick={fetchData} aria-label="Refresh">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Provider</TableHead>
                <TableHead>Load ref</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} className="py-12 text-center">
                    <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="py-12 text-center text-muted-foreground">
                    No transactions match your filters.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((row) => (
                  <TableRow key={row.id}>
                    <TableCell>
                      <p className="font-medium text-foreground">{row.userLabel}</p>
                      <p className="font-mono text-xs text-muted-foreground">
                        {row.id.slice(0, 8)}…
                      </p>
                    </TableCell>
                    <TableCell className="text-sm capitalize">{row.typeLabel}</TableCell>
                    <TableCell className="text-sm">
                      {PROVIDER_LABEL[row.provider] ?? row.provider}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {row.loadRef ?? '—'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm font-semibold">
                      {formatPrice(row.amount, row.currency as 'USD')}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={STATUS_VARIANT[row.status] ?? 'outline'}
                        className="capitalize text-[11px]"
                      >
                        {row.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {timeAgo(row.createdAt)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="border-t border-border px-4 py-3 text-xs text-muted-foreground">
          Showing {filtered.length} of {rows.length} transactions
        </div>
      </Card>
    </div>
  )
}
