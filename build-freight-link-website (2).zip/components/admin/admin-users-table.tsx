'use client'

import { useMemo, useState } from 'react'
import { Search, MoreHorizontal, UserCheck, UserX, Shield } from 'lucide-react'
import { toast } from 'sonner'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { mockUsers, countries, timeAgo } from '@/lib/data'

const ROLE_COLOR: Record<string, string> = {
  shipper: 'bg-blue-50 text-blue-700 border-blue-200',
  driver: 'bg-green-50 text-green-700 border-green-200',
  broker: 'bg-amber-50 text-amber-700 border-amber-200',
}

const SUB_COLOR: Record<string, string> = {
  free: 'bg-secondary text-secondary-foreground',
  monthly: 'bg-accent/15 text-accent-foreground',
  annual: 'bg-primary/10 text-primary',
}

export function AdminUsersTable() {
  const [query, setQuery] = useState('')
  const [roleFilter, setRoleFilter] = useState<string>('all')

  const filtered = useMemo(() => {
    let users = mockUsers
    if (query) {
      const q = query.toLowerCase()
      users = users.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.phone.includes(q) ||
          countries[u.country].name.toLowerCase().includes(q),
      )
    }
    if (roleFilter !== 'all') {
      users = users.filter((u) => u.role === roleFilter)
    }
    return users
  }, [query, roleFilter])

  return (
    <div className="flex flex-col gap-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by name, phone, country..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          {['all', 'shipper', 'driver', 'broker'].map((role) => (
            <Button
              key={role}
              size="sm"
              variant={roleFilter === role ? 'default' : 'outline'}
              onClick={() => setRoleFilter(role)}
              className="capitalize"
            >
              {role}
            </Button>
          ))}
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Country</TableHead>
                <TableHead>Subscription</TableHead>
                <TableHead className="text-right">Credits</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="w-10" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="py-12 text-center text-muted-foreground">
                    No users match your filters.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-foreground">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.phone}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium capitalize ${ROLE_COLOR[user.role]}`}>
                        {user.role}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">
                        {countries[user.country].flag} {countries[user.country].name}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${SUB_COLOR[user.subscription]}`}>
                        {user.subscription}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm">{user.credits}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {timeAgo(user.createdAt)}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => toast.info(`Viewing ${user.name}`)}>
                            <UserCheck className="mr-2 h-4 w-4" /> View profile
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast.info('Upgrade to admin coming soon')}>
                            <Shield className="mr-2 h-4 w-4" /> Grant admin
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => toast.error(`Suspended ${user.name} (demo only)`)}
                          >
                            <UserX className="mr-2 h-4 w-4" /> Suspend user
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="border-t border-border px-4 py-3 text-xs text-muted-foreground">
          Showing {filtered.length} of {mockUsers.length} users
        </div>
      </Card>
    </div>
  )
}
