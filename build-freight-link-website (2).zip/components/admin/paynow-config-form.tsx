'use client'

import { useState, useEffect } from 'react'
import { Save, Eye, EyeOff, CheckCircle, AlertTriangle, ExternalLink } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import {
  getPaynowConfig,
  savePaynowConfig,
  isPaynowConfigured,
  type PaynowConfig,
} from '@/lib/paynow'

export function PaynowConfigForm() {
  const [config, setConfig] = useState<PaynowConfig>({
    integrationId: '',
    integrationKey: '',
    returnUrl: '',
    resultUrl: '',
    merchantEmail: '',
    testMode: true,
  })
  const [showKey, setShowKey] = useState(false)
  const [saved, setSaved] = useState(false)

  // Load saved config on mount
  useEffect(() => {
    const saved = getPaynowConfig()
    // Fill URL defaults with current origin if empty
    setConfig({
      ...saved,
      returnUrl: saved.returnUrl || `${window.location.origin}/payment/return`,
      resultUrl: saved.resultUrl || `${window.location.origin}/api/paynow/result`,
    })
  }, [])

  const configured = isPaynowConfigured(config)

  function update(field: keyof PaynowConfig, value: string | boolean) {
    setSaved(false)
    setConfig((prev) => ({ ...prev, [field]: value }))
  }

  function handleSave() {
    if (!config.integrationId.trim()) {
      toast.error('Integration ID is required.')
      return
    }
    if (!config.integrationKey.trim()) {
      toast.error('Integration Key is required.')
      return
    }
    if (!config.merchantEmail.trim()) {
      toast.error('Merchant email is required.')
      return
    }
    savePaynowConfig(config)
    setSaved(true)
    toast.success('Paynow credentials saved.')
  }

  function handleClear() {
    const blank: PaynowConfig = {
      integrationId: '',
      integrationKey: '',
      returnUrl: `${window.location.origin}/payment/return`,
      resultUrl: `${window.location.origin}/api/paynow/result`,
      merchantEmail: '',
      testMode: true,
    }
    setConfig(blank)
    savePaynowConfig(blank)
    setSaved(false)
    toast.info('Paynow credentials cleared.')
  }

  return (
    <div className="space-y-5">
      {/* Status banner */}
      <div
        className={`flex items-start gap-3 rounded-lg border p-3 ${
          configured
            ? 'border-accent/30 bg-accent/5'
            : 'border-dashed border-muted-foreground/30 bg-muted/30'
        }`}
      >
        {configured ? (
          <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
        ) : (
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">
            {configured ? 'Paynow is configured' : 'Paynow credentials required'}
          </p>
          <p className="text-xs text-muted-foreground">
            {configured
              ? 'Payments are enabled. Test mode is ' + (config.testMode ? 'ON' : 'OFF') + '.'
              : 'Enter your Integration ID and Key from the Paynow merchant portal to enable payments.'}
          </p>
        </div>
        {configured && (
          <Badge
            variant="outline"
            className={config.testMode ? 'border-amber-300 text-amber-600' : 'border-accent/40 text-accent-foreground'}
          >
            {config.testMode ? 'Test mode' : 'Live'}
          </Badge>
        )}
      </div>

      {/* Portal link */}
      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
        Get your credentials from the{' '}
        <a
          href="https://www.paynow.co.zw/Account/Integrations"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-0.5 underline underline-offset-2 hover:text-foreground"
        >
          Paynow merchant portal <ExternalLink className="h-3 w-3" />
        </a>
      </p>

      {/* Fields */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>
            Integration ID <span className="text-destructive text-xs">*</span>
          </Label>
          <Input
            placeholder="e.g. 12345"
            value={config.integrationId}
            onChange={(e) => update('integrationId', e.target.value)}
            autoComplete="off"
          />
          <p className="text-xs text-muted-foreground">
            The numeric ID from your Paynow integration.
          </p>
        </div>

        <div className="space-y-1.5">
          <Label>
            Merchant email <span className="text-destructive text-xs">*</span>
          </Label>
          <Input
            type="email"
            placeholder="merchant@example.com"
            value={config.merchantEmail}
            onChange={(e) => update('merchantEmail', e.target.value)}
            autoComplete="off"
          />
          <p className="text-xs text-muted-foreground">
            Your registered Paynow account email.
          </p>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>
          Integration Key <span className="text-destructive text-xs">*</span>
        </Label>
        <div className="relative">
          <Input
            type={showKey ? 'text' : 'password'}
            placeholder="Paste your integration key"
            value={config.integrationKey}
            onChange={(e) => update('integrationKey', e.target.value)}
            autoComplete="off"
            className="pr-10 font-mono text-sm"
          />
          <button
            type="button"
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            onClick={() => setShowKey((v) => !v)}
            aria-label={showKey ? 'Hide key' : 'Show key'}
          >
            {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        <p className="text-xs text-muted-foreground">
          Secret key from the integration panel. Never share this publicly.
        </p>
      </div>

      <Separator />

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Return URL</Label>
          <Input
            value={config.returnUrl}
            onChange={(e) => update('returnUrl', e.target.value)}
            className="font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">
            Paynow redirects the user here after payment.
          </p>
        </div>
        <div className="space-y-1.5">
          <Label>Result URL (webhook)</Label>
          <Input
            value={config.resultUrl}
            onChange={(e) => update('resultUrl', e.target.value)}
            className="font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">
            Paynow POSTs the payment result to this URL.
          </p>
        </div>
      </div>

      {/* Test mode toggle */}
      <div className="flex items-center justify-between rounded-lg border border-border p-3">
        <div>
          <p className="text-sm font-medium">Test mode</p>
          <p className="text-xs text-muted-foreground">
            Use the Paynow sandbox — no real money charged.
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={config.testMode}
          onClick={() => update('testMode', !config.testMode)}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
            config.testMode ? 'bg-amber-400' : 'bg-accent'
          }`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
              config.testMode ? 'translate-x-1' : 'translate-x-6'
            }`}
          />
        </button>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleClear}
          className="text-muted-foreground hover:text-destructive"
        >
          Clear credentials
        </Button>
        <Button
          onClick={handleSave}
          className={`gap-2 ${saved ? 'bg-accent/80' : ''}`}
        >
          {saved ? (
            <CheckCircle className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saved ? 'Saved' : 'Save credentials'}
        </Button>
      </div>

      <p className="text-xs text-muted-foreground">
        Credentials are stored in your browser&apos;s local storage. Connect a
        database in the admin panel to persist them server-side.
      </p>
    </div>
  )
}
