"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { day: "Mon", posted: 38, matched: 22 },
  { day: "Tue", posted: 45, matched: 28 },
  { day: "Wed", posted: 52, matched: 31 },
  { day: "Thu", posted: 41, matched: 26 },
  { day: "Fri", posted: 58, matched: 39 },
  { day: "Sat", posted: 49, matched: 28 },
  { day: "Sun", posted: 29, matched: 13 },
]

const config = {
  posted: { label: "Loads Posted", color: "var(--chart-1)" },
  matched: { label: "Loads Matched", color: "var(--chart-2)" },
}

export function ActivityChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-base">Weekly load activity</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={config} className="h-[260px] w-full">
          <AreaChart data={data} margin={{ left: -16, right: 8, top: 8 }}>
            <defs>
              <linearGradient id="fillPosted" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-posted)" stopOpacity={0.7} />
                <stop offset="95%" stopColor="var(--color-posted)" stopOpacity={0.05} />
              </linearGradient>
              <linearGradient id="fillMatched" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-matched)" stopOpacity={0.7} />
                <stop offset="95%" stopColor="var(--color-matched)" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={8} />
            <YAxis tickLine={false} axisLine={false} width={32} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Area
              dataKey="posted"
              type="monotone"
              stroke="var(--color-posted)"
              fill="url(#fillPosted)"
              strokeWidth={2}
            />
            <Area
              dataKey="matched"
              type="monotone"
              stroke="var(--color-matched)"
              fill="url(#fillMatched)"
              strokeWidth={2}
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
