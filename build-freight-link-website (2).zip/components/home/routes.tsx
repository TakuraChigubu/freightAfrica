import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { popularRoutes, countries } from '@/lib/data'

export function PopularRoutes() {
  return (
    <section className="bg-secondary/40 py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <div className="max-w-xl">
            <h2 className="text-balance font-heading text-3xl font-700 tracking-tight sm:text-4xl">
              Popular corridors
            </h2>
            <p className="mt-3 text-muted-foreground">
              The busiest routes on the platform right now. Tap a corridor to see
              live loads.
            </p>
          </div>
          <Link
            href="/loads"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
          >
            View all loads <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {popularRoutes.map((route) => (
            <Link key={`${route.from}-${route.to}`} href="/loads">
              <Card className="flex items-center justify-between p-5 transition-all hover:-translate-y-0.5 hover:shadow-md">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{countries[route.fromCode].flag}</span>
                  <div>
                    <p className="font-heading font-600">
                      {route.from} <span className="text-accent">&rarr;</span> {route.to}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {route.loads} active loads
                    </p>
                  </div>
                </div>
                <span className="text-2xl">{countries[route.toCode].flag}</span>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
