import Link from 'next/link'
import Image from 'next/image'
import { Search, ArrowRight, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { platformStats } from '@/lib/data'

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-sidebar text-sidebar-foreground">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-freight.png"
          alt=""
          fill
          priority
          className="object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-sidebar via-sidebar/90 to-sidebar/40" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-sidebar-primary/40 bg-sidebar-primary/10 px-3 py-1 text-xs font-medium text-sidebar-primary">
            <Sparkles className="h-3.5 w-3.5" /> AI-powered freight matching
          </span>
          <h1 className="mt-5 text-balance font-heading text-4xl font-800 leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            Africa&apos;s smartest
            <span className="text-sidebar-primary"> freight load board</span>
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-sidebar-foreground/80">
            Post loads in seconds, find return trips instantly, and connect
            shippers with drivers across the African trucking corridor — starting
            Zimbabwe to South Africa.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="text-base">
              <Link href="/loads">
                <Search className="mr-2 h-5 w-5" /> Find loads
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-sidebar-foreground/30 bg-transparent text-base text-sidebar-foreground hover:bg-sidebar-foreground/10 hover:text-sidebar-foreground"
            >
              <Link href="/post-load">
                Post a load <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>

          <dl className="mt-12 grid max-w-md grid-cols-3 gap-6">
            {[
              { label: 'Loads this week', value: `${platformStats.loadsThisWeek}+` },
              { label: 'Countries', value: platformStats.countriesCovered },
              { label: 'Matched', value: `${platformStats.matchedThisWeek}` },
            ].map((stat) => (
              <div key={stat.label}>
                <dt className="text-sm text-sidebar-foreground/60">{stat.label}</dt>
                <dd className="font-heading text-2xl font-700 text-sidebar-primary">
                  {stat.value}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
