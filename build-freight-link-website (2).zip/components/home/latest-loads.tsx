import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { LoadCard } from '@/components/load-card'
import { mockLoads } from '@/lib/data'

export function LatestLoads() {
  const loads = mockLoads.slice(0, 6)
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
        <div className="max-w-xl">
          <h2 className="text-balance font-heading text-3xl font-700 tracking-tight sm:text-4xl">
            Latest loads
          </h2>
          <p className="mt-3 text-muted-foreground">
            Fresh freight posted across the corridor in the last few hours.
          </p>
        </div>
        <Link
          href="/loads"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          Browse all loads <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {loads.map((load) => (
          <LoadCard key={load.id} load={load} />
        ))}
      </div>
    </section>
  )
}
