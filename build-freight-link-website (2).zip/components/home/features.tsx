import {
  Bot,
  MessageCircle,
  CreditCard,
  Globe2,
  ShieldCheck,
  Zap,
} from 'lucide-react'
import { Card } from '@/components/ui/card'

const features = [
  {
    icon: Bot,
    title: 'AI natural-language search',
    body: 'Type "chrome loads to Johannesburg this week" and let the assistant surface the right matches instantly.',
  },
  {
    icon: MessageCircle,
    title: 'WhatsApp & Telegram',
    body: 'Loads broadcast on WhatsApp and Telegram are captured automatically and added to the board.',
  },
  {
    icon: CreditCard,
    title: 'Flexible payments',
    body: 'Pay $1 per contact, or go unlimited with monthly and annual plans. Card, EcoCash and mobile money.',
  },
  {
    icon: Globe2,
    title: 'Multi-currency',
    body: 'Quote and pay in USD, ZAR, ZMW, KES or NGN. Built for cross-border African trade.',
  },
  {
    icon: ShieldCheck,
    title: 'Verified contacts',
    body: 'Reduce fraud with verified shippers and drivers and a transparent transaction history.',
  },
  {
    icon: Zap,
    title: 'Real-time board',
    body: 'Fresh loads update live. Drivers find return trips before deadheading home empty.',
  },
]

export function Features() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-balance font-heading text-3xl font-700 tracking-tight sm:text-4xl">
          Everything you need to keep trucks full
        </h2>
        <p className="mt-4 text-pretty text-muted-foreground">
          FreightLink Africa brings shippers and drivers together with tools
          built specifically for the realities of African logistics.
        </p>
      </div>

      <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f) => (
          <Card key={f.title} className="p-6 transition-shadow hover:shadow-md">
            <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 font-heading text-lg font-600">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
          </Card>
        ))}
      </div>
    </section>
  )
}
