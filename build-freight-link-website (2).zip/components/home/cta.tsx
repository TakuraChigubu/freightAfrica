import Link from 'next/link'
import { MessageCircle, Send, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { siteConfig } from '@/lib/site'

export function CtaBand() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="overflow-hidden rounded-3xl bg-primary px-6 py-14 text-primary-foreground sm:px-12">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance font-heading text-3xl font-700 tracking-tight sm:text-4xl">
            Start moving freight today
          </h2>
          <p className="mt-4 text-pretty text-primary-foreground/80">
            Join shippers and drivers already using FreightLink Africa. Get
            instant load alerts on WhatsApp and Telegram, with the mobile app
            launching soon.
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" variant="secondary" className="text-base">
              <Link href="/post-load">Post your first load</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 bg-transparent text-base text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
            >
              <Link href="/pricing">See pricing</Link>
            </Button>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4 text-sm">
            <a
              href={siteConfig.contact.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-primary-foreground/80 transition-colors hover:text-sidebar-primary"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
            <a
              href={siteConfig.contact.telegram}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-primary-foreground/80 transition-colors hover:text-sidebar-primary"
            >
              <Send className="h-4 w-4" /> Telegram
            </a>
            <span className="inline-flex items-center gap-2 text-primary-foreground/60">
              <Smartphone className="h-4 w-4" /> iOS &amp; Android coming soon
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
