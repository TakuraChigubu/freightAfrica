"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AuthForm() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)

  function handleSubmit(e: React.FormEvent, mode: "signin" | "signup") {
    e.preventDefault()
    setLoading(true)
    // NOTE: Wire your real auth API here. This is a foundation-only placeholder.
    setTimeout(() => {
      setLoading(false)
      toast.success(mode === "signin" ? "Signed in (demo)" : "Account created (demo)", {
        description: "Connect your auth API to enable real authentication.",
      })
      router.push("/loads")
    }, 700)
  }

  return (
    <Card className="border-border/60 shadow-lg">
      <CardContent className="pt-6">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <Image
            src="/images/freightlink-logo.png"
            alt="FreightLink Africa"
            width={120}
            height={120}
            className="h-16 w-auto"
          />
          <div>
            <h1 className="font-heading text-xl font-bold text-foreground">Welcome to FreightLink Africa</h1>
            <p className="text-sm text-muted-foreground">Connect with loads and trucks across Africa</p>
          </div>
        </div>

        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form className="mt-4 flex flex-col gap-4" onSubmit={(e) => handleSubmit(e, "signin")}>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signin-email">Email</Label>
                <Input id="signin-email" type="email" placeholder="you@company.com" required />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signin-password">Password</Label>
                <Input id="signin-password" type="password" placeholder="••••••••" required />
              </div>
              <Button type="submit" disabled={loading} className="mt-2">
                {loading ? "Signing in..." : "Sign In"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form className="mt-4 flex flex-col gap-4" onSubmit={(e) => handleSubmit(e, "signup")}>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signup-name">Full name</Label>
                <Input id="signup-name" placeholder="John Banda" required />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signup-email">Email</Label>
                <Input id="signup-email" type="email" placeholder="you@company.com" required />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signup-role">I am a</Label>
                <Select defaultValue="shipper">
                  <SelectTrigger id="signup-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="shipper">Shipper / Broker (I post loads)</SelectItem>
                    <SelectItem value="carrier">Carrier / Trucker (I move loads)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="signup-password">Password</Label>
                <Input id="signup-password" type="password" placeholder="••••••••" required />
              </div>
              <Button type="submit" disabled={loading} className="mt-2">
                {loading ? "Creating account..." : "Create Account"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          By continuing you agree to our{" "}
          <Link href="/contact" className="underline underline-offset-2">
            terms
          </Link>{" "}
          and{" "}
          <Link href="/contact" className="underline underline-offset-2">
            privacy policy
          </Link>
          .
        </p>
      </CardContent>
    </Card>
  )
}
