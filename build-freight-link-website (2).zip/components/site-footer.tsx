import Link from 'next/link'
import Image from 'next/image'
import { MessageCircle, Send, Mail, Phone, Smartphone } from 'lucide-react'
import { siteConfig } from '@/lib/site'

const footerLinks = {
  Platform: [
    { title: 'Find Loads', href: '/loads' },
    { title: 'Post a Load', href: '/post-load' },
    { title: 'Pricing', href: '/pricing' },
    { title: 'How It Works', href: '/how-it-works' },
  ],
  Company: [
    { title: 'Contact', href: '/contact' },
    { title: 'Admin Panel', href: '/admin' },
    { title: 'Sign in', href: '/login' },
  ],
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-sidebar text-sidebar-foreground">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5">
              <Image
                src="/images/freightlink-logo.png"
                alt="FreightLink Africa"
                width={40}
                height={40}
                className="h-10 w-10 rounded-md bg-white object-contain p-0.5"
              />
              <span className="font-heading text-lg font-700">
                FreightLink <span className="text-sidebar-primary">Africa</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-sidebar-foreground/70">
              {siteConfig.tagline}. Connecting shippers and drivers across the
              African trucking corridor — starting Zimbabwe to South Africa.
            </p>
            <div className="mt-5 flex items-center gap-3">
              <a
                href={siteConfig.contact.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-accent transition-colors hover:bg-sidebar-primary hover:text-sidebar-primary-foreground"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
              <a
                href={siteConfig.contact.telegram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Telegram"
                className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-accent transition-colors hover:bg-sidebar-primary hover:text-sidebar-primary-foreground"
              >
                <Send className="h-5 w-5" />
              </a>
            </div>
          </div>

          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <h3 className="font-heading text-sm font-600 uppercase tracking-wider text-sidebar-foreground/90">
                {heading}
              </h3>
              <ul className="mt-4 space-y-2.5">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary"
                    >
                      {link.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-4 border-t border-sidebar-border pt-6 text-sm text-sidebar-foreground/60 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <span className="flex items-center gap-2">
              <Mail className="h-4 w-4" /> {siteConfig.contact.email}
            </span>
            <span className="flex items-center gap-2">
              <Phone className="h-4 w-4" /> {siteConfig.contact.phone}
            </span>
          </div>
          <p className="flex items-center gap-2">
            <Smartphone className="h-4 w-4" /> Mobile app coming soon
          </p>
        </div>
        <p className="mt-4 text-xs text-sidebar-foreground/50">
          &copy; {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
