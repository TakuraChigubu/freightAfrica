'use client'

import { useState } from 'react'
import { Loader2, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const subjects = [
  'General enquiry',
  'Load posting help',
  'Pricing & plans',
  'Technical support',
  'Partnership / bulk rates',
  'Other',
]

export function ContactForm() {
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitting(true)
    // Wire up to a backend API / email provider when ready
    await new Promise((r) => setTimeout(r, 900))
    setSubmitting(false)
    setDone(true)
    toast.success('Message sent!', {
      description: "We've received your message and will reply within one business day.",
    })
  }

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-secondary/40 py-12 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/15 text-accent-foreground">
          <CheckCircle2 className="h-7 w-7 text-accent" />
        </div>
        <h3 className="mt-4 font-heading text-lg font-semibold">Message received!</h3>
        <p className="mt-2 max-w-xs text-sm text-muted-foreground">
          We&apos;ll get back to you within one business day. For urgent matters, use WhatsApp.
        </p>
        <Button className="mt-6" variant="outline" onClick={() => setDone(false)}>
          Send another message
        </Button>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">Full name</Label>
          <Input id="name" name="name" placeholder="Tendai Moyo" required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email address</Label>
          <Input id="email" name="email" type="email" placeholder="you@example.com" required />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">WhatsApp / phone number</Label>
        <Input id="phone" name="phone" type="tel" placeholder="+263 77 123 4567" />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject">Subject</Label>
        <Select name="subject" defaultValue="General enquiry">
          <SelectTrigger id="subject">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {subjects.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Message</Label>
        <Textarea
          id="message"
          name="message"
          rows={5}
          placeholder="Tell us how we can help..."
          required
          className="resize-none"
        />
      </div>

      <Button type="submit" className="w-full" disabled={submitting}>
        {submitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Sending...
          </>
        ) : (
          'Send message'
        )}
      </Button>
    </form>
  )
}
