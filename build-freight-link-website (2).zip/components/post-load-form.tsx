'use client'

import { useState } from 'react'
import { Loader2, CheckCircle2, PackagePlus } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  countries,
  currencies,
  truckTypes,
  cargoCategories,
} from '@/lib/data'

export function PostLoadForm() {
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitting(true)
    // NOTE: Wire this up to POST /loads once your backend API is connected.
    await new Promise((r) => setTimeout(r, 900))
    setSubmitting(false)
    setDone(true)
    toast.success('Load submitted', {
      description: 'Your load is queued for posting. Connect your API to go live.',
    })
  }

  if (done) {
    return (
      <Card className="flex flex-col items-center justify-center p-10 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/20 text-accent-foreground">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h2 className="mt-4 font-heading text-xl font-700">Load submitted</h2>
        <p className="mt-2 max-w-sm text-sm text-muted-foreground">
          This is a demo submission. Once your backend API keys are connected,
          loads will be saved and broadcast to WhatsApp and Telegram subscribers.
        </p>
        <Button className="mt-6" onClick={() => setDone(false)}>
          Post another load
        </Button>
      </Card>
    )
  }

  return (
    <Card className="p-6 sm:p-8">
      <form onSubmit={handleSubmit} className="space-y-6">
        <fieldset className="space-y-4">
          <legend className="font-heading text-sm font-600 uppercase tracking-wider text-muted-foreground">
            Route
          </legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="originCity">Origin city</Label>
              <Input id="originCity" name="originCity" placeholder="Harare" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="originCountry">Origin country</Label>
              <Select name="originCountry" defaultValue="ZW">
                <SelectTrigger id="originCountry">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(countries).map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.flag} {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="destCity">Destination city</Label>
              <Input id="destCity" name="destCity" placeholder="Johannesburg" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="destCountry">Destination country</Label>
              <Select name="destCountry" defaultValue="ZA">
                <SelectTrigger id="destCountry">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(countries).map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.flag} {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="font-heading text-sm font-600 uppercase tracking-wider text-muted-foreground">
            Cargo
          </legend>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="cargoType">Cargo description</Label>
              <Input id="cargoType" name="cargoType" placeholder="Chrome ore" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cargoCategory">Category</Label>
              <Select name="cargoCategory" defaultValue={cargoCategories[0]}>
                <SelectTrigger id="cargoCategory">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cargoCategories.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="weight">Weight (tonnes)</Label>
              <Input id="weight" name="weight" type="number" min="0" step="0.5" placeholder="34" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="truckType">Truck type</Label>
              <Select name="truckType" defaultValue={truckTypes[0]}>
                <SelectTrigger id="truckType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {truckTypes.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </fieldset>

        <fieldset className="space-y-4">
          <legend className="font-heading text-sm font-600 uppercase tracking-wider text-muted-foreground">
            Rate &amp; contact
          </legend>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="price">Rate</Label>
              <Input id="price" name="price" type="number" min="0" placeholder="2200" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select name="currency" defaultValue="USD">
                <SelectTrigger id="currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(currencies).map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.code} ({c.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="contactPhone">Contact phone</Label>
              <Input id="contactPhone" name="contactPhone" placeholder="+263 77 000 0000" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="postedBy">Posted by</Label>
              <Input id="postedBy" name="postedBy" placeholder="Company or your name" required />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">Additional notes (optional)</Label>
            <Textarea id="notes" name="notes" placeholder="Loading times, special requirements, border details…" rows={3} />
          </div>
        </fieldset>

        <Button type="submit" size="lg" className="w-full" disabled={submitting}>
          {submitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting…
            </>
          ) : (
            <>
              <PackagePlus className="mr-2 h-4 w-4" /> Post load
            </>
          )}
        </Button>
      </form>
    </Card>
  )
}
