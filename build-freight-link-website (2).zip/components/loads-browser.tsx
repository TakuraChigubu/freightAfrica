'use client'

import { useEffect, useState, useCallback } from 'react'
import { Search, SlidersHorizontal, Sparkles, X, Loader2 } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { LoadCard } from '@/components/load-card'
import { countries, truckTypes, cargoCategories } from '@/lib/data'
import type { DbLoad } from '@/lib/supabase/queries'

// Map DbLoad (snake_case Supabase columns) to the shape LoadCard expects
function dbLoadToCardLoad(l: DbLoad) {
  return {
    id: l.reference,
    originCity: l.origin_city,
    originCountry: l.origin_country as import('@/lib/data').CountryCode,
    destCity: l.dest_city,
    destCountry: l.dest_country as import('@/lib/data').CountryCode,
    cargoType: l.cargo_type,
    cargoCategory: l.cargo_category,
    weightTonnes: l.weight_tonnes ?? 0,
    truckType: l.truck_type as import('@/lib/data').TruckType,
    price: l.price_amount ?? 0,
    currency: l.price_currency as import('@/lib/data').CurrencyCode,
    source: l.source,
    postedAt: l.posted_at,
    dbId: l.id, // raw UUID for unlock flow
  }
}

// For mock data (when Supabase not configured) the API returns camelCase-like objects
// that still match DbLoad shape — so dbLoadToCardLoad handles both.

const ALL = 'all'

export function LoadsBrowser() {
  const [query, setQuery] = useState('')
  const [debouncedQuery, setDebouncedQuery] = useState('')
  const [origin, setOrigin] = useState<string>(ALL)
  const [dest, setDest] = useState<string>(ALL)
  const [truck, setTruck] = useState<string>(ALL)
  const [category, setCategory] = useState<string>(ALL)
  const [sort, setSort] = useState<string>('newest')

  const [loads, setLoads] = useState<ReturnType<typeof dbLoadToCardLoad>[]>([])
  const [loading, setLoading] = useState(true)

  // Debounce the text query by 350 ms
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 350)
    return () => clearTimeout(t)
  }, [query])

  const fetchLoads = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (origin !== ALL) params.set('origin', origin)
    if (dest !== ALL) params.set('dest', dest)
    if (truck !== ALL) params.set('truck', truck)
    if (category !== ALL) params.set('category', category)
    if (debouncedQuery) params.set('q', debouncedQuery)
    params.set('sort', sort)

    try {
      const res = await fetch(`/api/loads?${params.toString()}`)
      const json = await res.json()

      // Normalise: mock data already has camelCase; Supabase returns snake_case.
      // The /api/loads route always returns DbLoad-shaped objects.
      const raw: DbLoad[] = json.loads ?? []
      setLoads(raw.map(dbLoadToCardLoad))
    } catch {
      setLoads([])
    } finally {
      setLoading(false)
    }
  }, [origin, dest, truck, category, debouncedQuery, sort])

  useEffect(() => {
    fetchLoads()
  }, [fetchLoads])

  const hasFilters =
    origin !== ALL || dest !== ALL || truck !== ALL || category !== ALL || query !== ''

  function reset() {
    setQuery('')
    setOrigin(ALL)
    setDest(ALL)
    setTruck(ALL)
    setCategory(ALL)
  }

  return (
    <div className="space-y-6">
      {/* Search + filters */}
      <div className="rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5">
        <div className="relative">
          <Sparkles className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-accent" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder='Try "chrome to Johannesburg" or "Durban flatbed"'
            className="h-12 pl-10 text-base"
            aria-label="Search loads"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-5">
          <Select value={origin} onValueChange={(v) => setOrigin(v ?? ALL)}>
            <SelectTrigger aria-label="Origin country">
              <SelectValue placeholder="Origin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any origin</SelectItem>
              {Object.values(countries).map((c) => (
                <SelectItem key={c.code} value={c.code}>
                  {c.flag} {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={dest} onValueChange={(v) => setDest(v ?? ALL)}>
            <SelectTrigger aria-label="Destination country">
              <SelectValue placeholder="Destination" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any destination</SelectItem>
              {Object.values(countries).map((c) => (
                <SelectItem key={c.code} value={c.code}>
                  {c.flag} {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={truck} onValueChange={(v) => setTruck(v ?? ALL)}>
            <SelectTrigger aria-label="Truck type">
              <SelectValue placeholder="Truck" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any truck</SelectItem>
              {truckTypes.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={category} onValueChange={(v) => setCategory(v ?? ALL)}>
            <SelectTrigger aria-label="Cargo category">
              <SelectValue placeholder="Cargo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Any cargo</SelectItem>
              {cargoCategories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sort} onValueChange={(v) => setSort(v ?? 'newest')}>
            <SelectTrigger aria-label="Sort">
              <SlidersHorizontal className="mr-1 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest first</SelectItem>
              <SelectItem value="price-high">Price: high to low</SelectItem>
              <SelectItem value="price-low">Price: low to high</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Result meta */}
      <div className="flex items-center justify-between">
        {loading ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading loads…
          </p>
        ) : (
          <p className="text-sm text-muted-foreground">
            <span className="font-semibold text-foreground">{loads.length}</span>{' '}
            {loads.length === 1 ? 'load' : 'loads'} found
          </p>
        )}
        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={reset}>
            <X className="mr-1 h-4 w-4" /> Clear filters
          </Button>
        )}
      </div>

      {/* Grid */}
      {!loading && loads.length > 0 && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {loads.map((load) => (
            <LoadCard key={load.id} load={load as never} />
          ))}
        </div>
      )}

      {!loading && loads.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-16 text-center">
          <Search className="h-10 w-10 text-muted-foreground/50" />
          <p className="mt-4 font-heading text-lg font-semibold">No loads match your search</p>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">
            Try widening your filters, or ask the AI assistant to help you find a return load.
          </p>
          <Button variant="outline" className="mt-4" onClick={reset}>
            Reset search
          </Button>
        </div>
      )}

      {loading && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-52 animate-pulse rounded-2xl border border-border bg-muted"
            />
          ))}
        </div>
      )}
    </div>
  )
}
