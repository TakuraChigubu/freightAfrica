'use client'

import { useState, useEffect } from 'react'
import { CreditCard, ExternalLink, AlertTriangle, User, Mail, Loader2, Settings } from 'lucide-react'
import Link from 'next/link'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import { getPaynowConfig, isPaynowConfigured, type PaynowConfig } from '@/lib/paynow'

interface PaynowCheckoutModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Unique order reference, e.g. "PLAN-monthly-1234" or "LOAD-LD-042-1234" */
  reference: string
  /** Amount in USD */
  amount: number
  /** Human-readable label shown in the dialog */
  description: string
  /** Optional badge tag shown below the description */
  tag?: string
}

export function PaynowCheckoutModal({
  open,
  onOpenChange,
  reference,
  amount,
  description,
  tag,
}: PaynowCheckoutModalProps) {
  const [config, setConfig] = useState<PaynowConfig | null>(null)
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [emailError, setEmailError] = useState('')

  // Load config from localStorage on open
  useEffect(() => {
    if (open) {
      setConfig(getPaynowConfig())
      setEmail('')
      setName('')
      setEmailError('')
      setLoading(false)
    }
  }, [open])

  const configured = config ? isPaynowConfigured(config) : false

  // Build the result and return URLs using the current origin
  function buildUrls() {
    const origin = window.location.origin
    return {
      returnUrl: config?.returnUrl || `${origin}/payment/return?reference=${encodeURIComponent(reference)}`,
      resultUrl: config?.resultUrl || `${origin}/api/paynow/result`,
    }
  }

  function validate() {
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setEmailError('A valid email address is required by Paynow.')
      return false
    }
    setEmailError('')
    return true
  }

  async function handlePay() {
    if (!config || !validate()) return
    setLoading(true)

    const { returnUrl, resultUrl } = buildUrls()

    try {
      const res = await fetch('/api/paynow/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          integrationId: config.integrationId,
          integrationKey: config.integrationKey,
          returnUrl,
          resultUrl,
          merchantEmail: config.merchantEmail,
          reference,
          amount,
          email: email.trim(),
          description: `${description}${name.trim() ? ` — ${name.trim()}` : ''}`,
          name: name.trim() || undefined,
        }),
      })

      const data = await res.json()

      if (!data.success) {
        toast.error(`Paynow error: ${data.error}`)
        setLoading(false)
        return
      }

      // Open the Paynow hosted payment page in a new tab
      window.open(data.browserUrl, '_blank', 'noopener,noreferrer')
      toast.success('Redirecting to Paynow...')
      onOpenChange(false)
    } catch {
      toast.error('Could not reach Paynow. Check your internet connection.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-accent" />
            Pay via Paynow
          </DialogTitle>
          <DialogDescription>
            {description}
            {tag && (
              <Badge variant="secondary" className="ml-2 align-middle text-xs">
                {tag}
              </Badge>
            )}
          </DialogDescription>
        </DialogHeader>

        {/* Not configured */}
        {!configured && (
          <div className="space-y-3 rounded-lg border border-dashed border-destructive/40 bg-destructive/5 p-4">
            <div className="flex items-start gap-2 text-sm text-destructive">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <p>
                Paynow credentials are not configured. Add your Integration ID,
                Key and merchant email in Admin Settings to enable payments.
              </p>
            </div>
            <Button asChild variant="outline" size="sm" className="gap-2">
              <Link href="/admin/settings" onClick={() => onOpenChange(false)}>
                <Settings className="h-3.5 w-3.5" />
                Go to Admin Settings
              </Link>
            </Button>
          </div>
        )}

        {/* Configured — show form */}
        {configured && (
          <>
            {/* Order summary */}
            <div className="rounded-lg border border-border bg-muted/30 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Reference</span>
                <span className="font-mono text-xs">{reference}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Amount</span>
                <span className="font-heading text-lg font-bold text-primary">
                  ${amount.toFixed(2)} USD
                </span>
              </div>
            </div>

            {/* Payer details */}
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-muted-foreground" />
                  Your name{' '}
                  <span className="text-xs text-muted-foreground">(optional)</span>
                </Label>
                <Input
                  placeholder="e.g. John Moyo"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                  disabled={loading}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                  Email address{' '}
                  <span className="text-xs text-destructive">*</span>
                </Label>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    setEmailError('')
                  }}
                  autoComplete="email"
                  disabled={loading}
                  className={emailError ? 'border-destructive' : ''}
                />
                {emailError && (
                  <p className="text-xs text-destructive">{emailError}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Paynow sends your receipt to this address.
                </p>
              </div>
            </div>

            <div className="flex gap-2 pt-1">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => onOpenChange(false)}
                disabled={loading}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 gap-2 bg-accent text-accent-foreground hover:bg-accent/90"
                onClick={handlePay}
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ExternalLink className="h-4 w-4" />
                )}
                {loading ? 'Processing...' : `Pay $${amount.toFixed(2)} via Paynow`}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
